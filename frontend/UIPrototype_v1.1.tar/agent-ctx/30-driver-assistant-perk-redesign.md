# Task ID: 30 — Driver + Assistant perk-style redesign

**Agent:** full-stack-developer (Driver+Assistant perk redesign)
**Scope:** `src/components/bus/roles/driver-module.tsx` (6 screens), `src/components/bus/roles/assistant-module.tsx` (7 screens)

## Work Log
1. READ worklog.md Task 28 design mandate + both target files + `primitives.tsx` (StatCard/PageHeader/Section/EmptyState) + `m3/primitives.tsx` (ExpressiveCard/Button, StatusPill, Chip) + `globals.css` to confirm CSS token overrides (primary-container=#14140f, secondary-container=#144fcc, tertiary-container=#ff8c5f, success/error/warning containers all bold).
2. **Driver module** edits:
   - `HorizontalTimeline` + `VerticalTimeline`: done circles → `bg-[#144fcc] text-white` (bold blue), active circles → `bg-[#beff50] text-[#14140f]` (bold lime), ping rings → `bg-[#beff50]/40`, connector lines → `bg-[#144fcc]`, active stop labels → `text-[#144fcc]`. Added `min-w-0` + `truncate` on stop name/address/time cells.
   - `RouteMapSVG`: live-position dot → `bg-[#144fcc] animate-pulse` (was pale lime). SVG strokes left on `var(--m3-primary)` (renders lime, readable on the dark aurora-tinted map bg).
   - `DriverDashboard`: greeting row + `min-w-0` + `truncate` on subtitle; active-trip HERO card rewritten from pale lime→coral aurora gradient to **bold dark `bg-[#14140f]`** with lime accent stripe, lime ping badge, white headlines, lime stat tiles (`bg-white/10`), lime CTA button (`bg-[#beff50] text-[#14140f]`). Schedule list icon `text-primary` → `text-[#144fcc]`. Route preview icon → `text-[#144fcc]`. (StatCards already used bold accent prop; rating card already `bg-tertiary-container`.)
   - `DriverSchedule`: today date `text-primary` → `text-[#144fcc]`; trip-card departure chip `bg-primary-container` already bold (kept) — explicit `bg-[#14140f] text-[#beff50]` for clarity; added `min-w-0` + `truncate` on route title.
   - `DriverActiveTrip` (HERO): rewritten pale aurora → **bold dark `bg-[#14140f]`** card with status pill that swaps lime (running) ↔ coral (idle), big lime timer, lime progress bar, lime "Bắt đầu chuyến" button + red "Kết thúc chuyến" + outlined lime "+1 khách". All headline/body text → `text-white` / `text-[#beff50]`. Side panel: passenger-counter progress → `bg-[#144fcc]`; icon accents → `text-[#144fcc]`; assistant card avatar container now `shrink-0` + phone `truncate`.
   - `DriverRoute`: route hero rewritten from `linear-gradient(ROUTE.color...)` pale lime → **bold dark `bg-[#14140f]`** with lime code badge, green/coral active badge, lime arrow, white stat tiles. Stop-list + bus-info icons → `text-[#144fcc]`; grid `min-w-0`.
   - `DriverHistory`: StatCards already bold; table unchanged (overflow-x already handled by parent).
   - `DriverContact`: chat "me" bubble `bg-primary text-on-primary` → `bg-[#144fcc] text-white` (bold blue, readable); timestamp → `text-white/70`; message text `break-words`. (Coordinator avatar already `bg-tertiary-container` bold coral.)
3. **Assistant module** edits:
   - `AssistantDashboard`: greeting + `min-w-0` + `truncate`. Trip-info HERO rewritten pale lime→coral aurora → **bold dark `bg-[#14140f]`** with lime stripe, lime badge, white headlines, lime stat tiles, lime bus icon tile. Driver-contact side card avatar `shrink-0` + phone `truncate`; "Gọi" button `text-primary` → `text-[#144fcc]`. (Quick-action tiles already use bold container tokens; StatCards already bold.)
   - `AssistantScan`: viewfinder kept dark with lime scan-line / corner brackets / center QR icon (bold on dark). Status icon circles already bold (`bg-success/warning/error-container`).
   - `AssistantMonthly`: result HERO rewritten pale coral→lime aurora → **bold dark `bg-[#14140f]`** with lime stripe, **green "VÉ THÁNG HỢP LỆ" badge** (success signal), lime days-left counter, white stat tiles, lime CTA button.
   - `AssistantLost`: form header icon `text-primary` → `text-[#144fcc]`. (List leading icon already `bg-tertiary-container` bold.)
   - `AssistantIncident`: type-button selected state already `bg-secondary-container` (bold blue); severity icon circles already bold containers — kept.
   - `AssistantContact`: chat "me" bubble → `bg-[#144fcc] text-white`; sender name labels → `text-[#ff8c5f]` (driver) / `text-[#144fcc]` (coordinator) explicit; timestamp → `text-white/70`; message text `break-words`. (Two contact cards already use bold primary/tertiary container avatars.)
   - `AssistantHistory`: StatCards already bold; table unchanged.
4. Ran `bun run lint` — **clean, no errors**. Dev server compiles cleanly (dev.log shows repeated `✓ Compiled in XXXms` with no warnings).

## Stage Summary
- **Files:** `src/components/bus/roles/driver-module.tsx`, `src/components/bus/roles/assistant-module.tsx`
- **Lint:** PASS (0 errors, 0 warnings)
- **Hero cards (5):** DriverDashboard active-trip, DriverActiveTrip hero, DriverRoute hero, AssistantDashboard trip-info, AssistantMonthly result — ALL converted from pale lime/coral aurora gradients to **bold dark `#14140f` cards** with lime `#beff50` accent stripes + lime badges/CTAs + white headlines.
- **Timeline circles:** done = bold blue `#144fcc`, active = bold lime `#beff50` (was pale lime throughout).
- **Icon accents on light cards:** all `text-primary` (lime, unreadable on light) → `text-[#144fcc]` (blue) or `text-[#14140f]` (dark). Only remaining `bg-primary text-on-primary` is the week-selector selected day (bold lime block — intentional brand accent).
- **Chat bubbles:** "me" bubbles → bold blue `#144fcc` + white text (was pale lime + dark).
- **Mobile fix:** `min-w-0` + `truncate` added to all flex/grid text children in greetings, hero headlines, timeline cells, contact cards, trip lists, route stat tiles.
- **Already-bold tokens preserved:** `bg-primary-container` (dark), `bg-secondary-container` (blue), `bg-tertiary-container` (coral), `bg-success/error/warning-container` — all already render bold per Task 28 CSS overrides; no changes needed.
