# Task 29 — Redesign common-screens perk-style + mobile fix

**Agent**: full-stack-developer (common-screens perk redesign)
**File**: `src/components/bus/common-screens.tsx` (only file modified)
**Task**: Redesign Profile/Notifications/Support/Settings/MyUniversity perk-style + mobile fix

## Context read
- `worklog.md` Task 28: design mandate — kill pale tonal containers globally. Bold palette: primary=#beff50 lime (on-primary=#14140f off-black), secondary=#144fcc blue, tertiary=#ff8c5f coral, error=#dc2626, success=#16a34a, warning=#f59e0b, purple=#c8a0ff. Containers BOLD (dark/saturated), NOT washed-out tints.
- `globals.css`: perk theme is scoped to `[data-role-theme="student"]`. Default `:root` tokens are still pale M3 (e.g. `--m3-primary-container: oklch(0.90 0.07 156)` = pale green). Because common-screens render across ALL roles, I used **literal hex colors** (`bg-[#14140f]`, `text-[#beff50]`, `bg-[#144fcc]`, etc.) instead of `bg-primary-container` to guarantee perk-style bold rendering everywhere.
- `primitives.tsx`: `StatCard` accent map already bold (primary→#14140f bg + lime fg, tertiary→#ff8c5f, success→#16a34a). `ExpressiveCard` filled = `bg-surface-container-high` (warm off-white) — fine as a surface.
- `m3/primitives.tsx`: `ExpressiveButton` outlined variant uses `text-primary` (invisible lime on warm-white outside student scope). Override with `text-[#14140f] border-[#14140f]` for needed cases.
- `mock-data.ts`: universities have `logoUrl` (real images) + `color` fields. Default student `universityId` = uni1 (Duy Tân, color #1a73e8).

## Work Log

### ProfileScreen
- `ROLE_COLORS` rewritten as `{ bg, fg }` map with literal hex per role: student→#beff50/#14140f, driver→#ff8c5f/#14140f, assistant→#144fcc/#fff, coordinator→#c8a0ff/#14140f, admin→#dc2626/#fff, university_admin→#144fcc/#fff.
- Avatar fallback: applied via inline `style={{ backgroundColor, color }}` so the bold color is guaranteed regardless of role theme scope.
- Camera button: `bg-[#beff50] text-[#14140f]` literal (was `bg-primary text-on-primary`).
- Verification badges: bold pills — role pill = `bg-[#14140f] text-[#beff50]` (dark+lime); verified pill = `bg-[#beff50] text-[#14140f]` with BadgeCheck icon (lime+dark); Google pill = `bg-[#144fcc] text-white` (blue+white).
- Info card: `bg-surface-container-low` (warm off-white, not pale-green tonal).
- **Security section** rebuilt as a dark accent card: `bg-[#14140f] text-white` with a lime icon chip (`bg-[#beff50] text-[#14140f]`) and a lime "Đổi mật khẩu" button (`bg-[#beff50] text-[#14140f]`). 2-step toggle row uses `bg-white/10` divider.

### NotificationsScreen
- `typeStyle` map rewritten: each type = bold color text on 20% opacity tinted bg. info→`bg-[#144fcc]/15 text-[#144fcc]`, success→`bg-[#16a34a]/15 text-[#16a34a]`, warning→`bg-[#f59e0b]/15 text-[#f59e0b]`, danger→`bg-[#dc2626]/15 text-[#dc2626]`.
- **Unread dot**: `bg-[#144fcc]` (blue — was `bg-primary` which renders invisible lime on warm-white outside student scope).
- Unread card border/bg: `border-[#144fcc]/40 bg-[#144fcc]/5`.
- "Đánh dấu đã đọc" button: `variant="outlined" className="border-[#14140f] text-[#14140f]"` (was `text-primary` = invisible).

### SupportScreen
- Contact cards: bold icon circles per contact — Phone→blue `#144fcc`+white, Mail→coral `#ff8c5f`+dark, MapPin→dark `#14140f`+lime (was `bg-primary-container text-on-primary-container` = pale in non-student scope). Applied via inline style to support per-row colors.
- **Success confirmation** rebuilt as dark card with lime accent: `bg-[#14140f] text-white` with a `bg-[#beff50] text-[#14140f]` CheckCircle2 chip; title in `text-[#beff50]` lime; body in `text-white/80`. Was pale `bg-success-container/40`.
- Form card: `bg-surface-container-low`.

### SettingsScreen
- Both toggle cards: `bg-surface-container-low` (warm off-white, was `bg-surface-container-high`).
- Section header text: `text-[#14140f] font-bold` (was `text-base` default). Privacy header Shield icon tinted `text-[#144fcc]` blue.
- All toggle row text labels wrapped with `min-w-0` + `truncate` for mobile.

### MyUniversityScreen
- University hero: real `logoUrl` in white rounded container (`bg-white p-2 rounded-3xl elev-2`), gradient from `uni.color` subtle (uses `${uni.color}1f` = ~12% opacity alpha).
- Verification StatCards: already bold via `primitives.tsx` accent map — accent="success" (#16a34a + white), accent="primary" (#14140f + lime), accent="tertiary" (#ff8c5f + dark). Updated the success value text to `text-white` for contrast on green.
- Route list icon circles: per-route bold colors. DN-01 → lime `#beff50` + dark icon, DN-03 → blue `#144fcc` + white icon (was `bg-primary-container text-on-primary-container` = pale). Route code text → `text-[#14140f]` (was `text-primary` = invisible lime).
- Route final price → `text-[#16a34a]` (literal success green, was `text-success` which is fine but literal keeps consistency).
- **Subsidy card** rebuilt as bold coral block: `bg-[#ff8c5f] text-[#14140f]` with a dark icon chip (`bg-[#14140f] text-[#beff50]` Gift icon). Subsidy text uses `text-[#14140f]/80` for secondary lines, divider `bg-[#14140f]/15`.

### Mobile fixes (all screens)
- Root wrapper for every screen: `min-w-0 overflow-x-hidden`.
- Every flex/grid child with text: added `min-w-0` and `truncate` where appropriate (avatar card name/email/role fields, contact list items, toggle row labels, route list name/from-to, subsidy card line items).
- Notification title: `truncate` to prevent overflow.
- All icon circles: `shrink-0` to prevent squish.

## Lint
- `bun run lint` → **exit 0, 0 errors, 0 warnings** (initial run had 1 unused eslint-disable warning for `<img>` in logoUrl; removed the directive — plain `<img>` is allowed in this project config).
- Dev log clean — successful compilation, all routes 200.

## Stage Summary
- All 5 common screens (Profile / Notifications / Support / Settings / MyUniversity) redesigned perk-style: bold color blocks, dark accent cards, blue unread dot, dark+lime security/success/subsidy cards.
- Used **literal hex colors** throughout (not CSS tokens) so the perk palette renders consistently across ALL roles, not just student scope.
- Mobile overflow fixed: `min-w-0` + `truncate` + `overflow-x-hidden` applied to every text-bearing flex/grid child + root wrapper.
- File modified: only `src/components/bus/common-screens.tsx`.
- Lint clean, dev server compiles successfully.
