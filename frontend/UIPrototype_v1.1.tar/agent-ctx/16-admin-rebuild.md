# Task 16 — Rebuild Admin Module in M3 Expressive + GSAP motion + university management

## Agent
full-stack-developer (Admin rebuild)

## Task
Rebuild Admin module (10 screens incl. 4 new university-management screens) in Material 3 Expressive + GSAP-style motion. Frontend-only, mock data, Đà Nẵng.

## File Modified
- `src/components/bus/roles/admin-module.tsx` — OVERWROTE completely with M3 Expressive rebuild

## Foundation Used
- `src/components/m3/primitives.tsx` — ExpressiveButton, ExpressiveCard, StatusPill, M3Progress, Chip
- `src/components/m3/motion.tsx` — SplitText, ScrollReveal, StaggerGroup/StaggerItem, Counter
- `src/components/bus/primitives.tsx` — PageHeader, StatCard, Section, EmptyState, ExpressiveCard
- `src/lib/mock-data.ts` — allUsers, complaints, incidents, routes, universities, universityAdmins, routeUniversities, auditLogs, universityStats, formatVND, universityById

## Screens Built (10 total)

### Rebuilt (existing screens refreshed to M3 Expressive)
1. `adm-dashboard` (REQ-ADM-005) — SplitText title "Thống kê hệ thống", 4 StatCards with Counter (1.248 users / 113 trips today / 94.6M revenue / 92% on-time), ScrollReveal charts: recharts AreaChart (7-day revenue gradient), BarChart (trips per route with route colors), PieChart (role distribution incl. University Admin role), StaggerGroup activity feed (max-h-96 scroll), "Cảnh báo hệ thống" panel with StatusPill tones (error/warning/neutral).
2. `adm-users` (REQ-ADM-004 + 001) — search + role filter (incl. University Admin) + status filter, sticky-header table inside max-h-[500px] scrollbar-soft, RolePill/UserStatusPill color-coded, dropdown actions (Xem chi tiết / Khóa-Mở khóa AlertDialog / Đặt lại MK AlertDialog), "Thêm người dùng" Dialog, detail Dialog, pagination footer (8 per page).
3. `adm-complaints` (REQ-ADM-002) — 4 Counter StatCards (Mới/Đang xử lý/Đã giải quyết/Từ chối), pill Tabs with live counts, table of `complaints`, detail Dialog with resolution Textarea + 3 action buttons (Đang xử lý outlined / Đã giải quyết tonal / Từ chối error).
4. `adm-violations` (REQ-ADM-003) — combined `incidents` + 4 mock violations, 4 StatCards, "Phân loại vi phạm" card with M3Progress horizontal bars (max-count normalized), severity + status Selects filter, table, detail Dialog with "Đánh giá & Chuyển xử lý" action.
5. `adm-fare` (REQ-ADM-007) — Table of `routes` (color dot, code+name, frequency, vé lượt, vé tháng, Sửa button), "Áp dụng tháng tiếp theo" Switch in header, edit Dialog with new fare + new pass inputs + live % change indicator (rose up / emerald down, Percent icon), effective date, reason textarea, apply-next toggle, "Lịch sử điều chỉnh" card with 4 mock entries (old→new with TrendingUp/Down icons + StatusPill Tăng/Giảm).
6. `adm-notify` (REQ-ADM-006) — compose form (audience Select incl. "Theo trường"/"Theo campus" with conditional university selector, title+counter 80, message+counter 240, priority Select, schedule toggle now/later with datetime-local), live preview ExpressiveCard with phone-frame UI (rounded-[2.5rem] border + status bar + notification card with priority-toned icon), "Gửi thông báo" button, recent sent table (5 mock entries).

### NEW (university-management)
7. `adm-universities` — StaggerGroup StatCards (4 unis / 2.536 students / 2 subsidized / 6 routes-assigned), table of `universities` (UniLogo color box + name + code, campuses count, domains count, students count, routes count, subsidy StatusPill, status Switch), search input, "Thêm trường" Dialog (code/name/shortName/contactEmail/address), row detail Dialog (edit info + campuses list with MapPin + domains as Chips), lock/unlock AlertDialog.
8. `adm-uni-admins` — StatCards (total / active / pending / locked), table of `universityAdmins` (avatar initials + name + email, university StatusPill, status pill, createdAt, lastLogin, actions dropdown: Kích hoạt/Khóa AlertDialog / Đặt lại mật khẩu AlertDialog / Xóa), "Thêm University Admin" Dialog (select university + name + email).
9. `adm-route-uni` — two-pane layout: left = routes list (color dot + code + name + "N trường" pill), right = universities list (UniLogo + shortName + "N tuyến" pill). Click route → highlights matching column. Click university → highlights matching row. Below: visual mapping matrix table with rows=routes × cols=universities, each cell has Switch toggle to assign/unassign. Active mappings summarized as Chips at bottom (route color dot ↔ uni code). Toggle updates local state + toast.
10. `adm-audit` — StatCards (total events / success / failure / today), filter bar (search input + role Select incl. admin/uni_admin/coordinator + result Select success/failure), sticky-header table inside max-h-[560px] scrollbar-soft of `auditLogs` (timestamp / actor avatar with role-tinted bg + role label / action+target / university pill / result StatusPill success=success/failure=error / IP mono). EmptyState fallback. Footer with counts.

## M3 Expressive Rules Applied
- Tonal color roles only: bg-surface-container-*, bg-primary-container, bg-tertiary-container, bg-secondary-container, bg-error-container, bg-warning-container, bg-success-container. NO indigo/blue, NO raw tailwind emerald/amber/rose except where needed for chart Cell fills (used route.color from mock data which includes #10b981/#f59e0b/#14b8a6/#ec4899 — these are route-identity colors, not theme colors).
- Shape scale: rounded-xl (cards/table cells), rounded-2xl (stat tiles/dialogs/logos), rounded-full (buttons/pills/tabs/selects).
- Tonal elevation: elev-1/2/3 from globals.css utilities.
- state-layer on all interactive elements (ExpressiveButton, DropdownMenu triggers, route/uni list buttons).
- Spring motion via framer-motion (StatCard hover y-4, AlertDialogAction spring press inherited from ExpressiveButton when used).
- Mobile-first responsive (grid-cols-2 → lg:grid-cols-4, sm:/lg: breakpoints).
- scrollbar-soft on all long lists (max-h-96 / max-h-[420px|460px|500px|520px|560px]).
- Admin "clean but SOFT, warm cream bg" — uses surface-container-* layers on top of body's warm cream bg (oklch 0.992 0.003 155).

## GSAP-style Motion Cues
- Dashboard title: SplitText (word-by-word clip reveal).
- StatCards: StaggerGroup + Counter (count-up animation when in view).
- Charts: ScrollReveal (fade + translate + spring) — applied to AreaChart, BarChart, PieChart, warnings panel, activity feed.
- Activity feed: StaggerGroup with StaggerItem children (blur-in reveal).
- All StatCards across screens wrapped in StaggerGroup/StaggerItem for consistent reveal.

## Implementation Notes
- shadcn Table used with sticky TableHeader (bg-surface-container-high) inside max-h-[...] overflow-y-auto scrollbar-soft containers.
- recharts ResponsiveContainer with theme tokens: var(--color-primary), var(--color-tertiary), var(--color-secondary), var(--color-chart-4/5), var(--color-outline-variant) for grid, var(--color-on-surface-variant) for axis.
- Confirmations all use AlertDialog (lock/unlock user, lock/unlock university, reset password, lock university admin).
- Status/role badges all use StatusPill with tones (primary/tertiary/success/warning/error/neutral) — no more raw Tailwind color classes for status badges (M3 tonal only).
- Filters use Tabs (complaints) or Select (audit/violations/users/fare).
- toast from sonner for all action feedback.
- For adm-route-uni matrix: two-pane selection + visual matrix table with switches is the cleanest UX. Toggling a switch updates local `mappings` state and shows toast. Active mappings rendered as Chips below matrix.
- ExpressiveButton used everywhere instead of shadcn Button (M3 primitives preferred per task spec).
- ExpressiveCard used instead of shadcn Card for all container cards.
- Did NOT handle adm-profile / adm-notifications (handled by common-screens.tsx per orchestrator convention).

## Lint Status
`bun run lint` → 0 errors, 0 warnings ✓
Note: dev.log shows a separate unrelated error about missing `@/components/bus/roles/university-admin-module` — that is a different parallel task (Task ID for university-admin module), NOT my file. My admin-module.tsx compiles clean (lint exit 0).

## Did NOT modify
- Any file other than `src/components/bus/roles/admin-module.tsx` and worklog.md
- No test files
