# Task ID: 32 — Redesign Admin + University-Admin modules to perk-style + mobile fix

Agent: full-stack-developer (Admin + University-Admin perk redesign)
Scope: `src/components/bus/roles/admin-module.tsx` (10 screens) + `src/components/bus/roles/university-admin-module.tsx` (9 screens)

## Design mandate applied (per Task 28 — perk.com style, NO pale containers)

Palette: primary=#beff50 lime, secondary=#144fcc blue, tertiary=#ff8c5f coral,
error=#dc2626, success=#16a34a, warning=#f59e0b, purple=#c8a0ff, off-black=#14140f.
CSS tokens already bold (primary-container=#14140f, secondary-container=#144fcc,
tertiary-container=#ff8c5f, etc.) — so existing `bg-*-container` usages now render BOLD automatically.

## Work Log

### admin-module.tsx (10 screens)
- **Charts → perk palette**: Dashboard revenue AreaChart stroke switched from
  `var(--color-primary)` (lime, poor contrast on white) to `#144fcc` blue; gradient
  stops updated to blue. Role-distribution PieChart colors switched from
  `var(--color-chart-4/5)` (oklch) to literal perk hex (#beff50, #ff8c5f, #144fcc,
  #c8a0ff, #f59e0b). All recharts tooltips now use bold dark bg `#14140f` + lime
  text `#beff50` for high contrast.
- **Mobile overflow**: added `min-w-0` + `truncate` to: roleDist legend labels,
  user-detail dialog name, fare-history list items (route + reason lines).
  Added `shrink-0` to tabular-nums value spans and color dots to prevent squish.
- **Tables**: all 7 tables already wrapped in `overflow-x-auto scrollbar-soft`
  containers with `max-h-[XX]px overflow-y-auto` — verified, no change needed.
- **StatCards**: all 4 bold accent blocks (primary/tertiary/success/secondary) via
  shared `StatCard` primitive — already perk-style, no change needed.
- **Activity feed**: tint classes `bg-primary-container text-on-primary-container`
  etc now resolve to bold dark/coral/blue blocks automatically — kept as-is.
- **Universities table**: real `logoUrl` rendered in white rounded container via
  `UniLogo` helper — already correct.
- **Route↔Uni matrix**: desktop overflow-x-auto + mobile stacked cards — already
  correct, added `min-w-0` to mobile stacked labels.

### university-admin-module.tsx (9 screens)
- **Charts → perk palette**: replaced ALL old-palette chart fills:
  - `passesByRoute` (Dashboard + Stats): #10b981/#f59e0b/#14b8a6 → #beff50/#144fcc/#ff8c5f
  - `facultyDist` (Stats pie): #10b981/#f59e0b/#14b8a6/#ec4899/#9333ea → #beff50/#144fcc/#ff8c5f/#c8a0ff/#f59e0b
  - `topRoutes` (Stats table): #10b981/#f59e0b/#14b8a6 → #beff50/#144fcc/#ff8c5f
  - 2 LineCharts (Dashboard trips7, Stats trips30): stroke `var(--m3-primary)` → `#144fcc`
    (lime stroke invisible on white card → blue stroke high-contrast)
- **Killed pale-tint containers** (4 spots — design mandate: AVOID pale tints):
  - Domains intro card: `bg-primary-container/40` → `bg-surface-container-low` (neutral off-white, bold icon keeps accent)
  - Import error banner: `bg-warning-container/60` → `bg-warning-container text-[#14140f]` (BOLD amber + dark text)
  - Roster status-dialog info note: `bg-secondary-container/50` → `bg-surface-container-low border border-outline-variant/40`
  - Recon note card: `bg-secondary-container/40` → `bg-surface-container-low`
- **`text-primary` on light bg → `text-[#144fcc]`**: Recon summary `CalendarDays`
  icon (lime on white = invisible → blue = high-contrast).
- **Mobile overflow**: added `min-w-0` + `truncate` to: quick-action card labels
  (Dashboard), campus card name (Info), domains table cell (domain + @handle),
  roster table cell (fullName + email), top-routes table cell (code + name),
  recon breakdown table cell (code + route).
- **University hero**: real `logoUrl` in white rounded container (`size-20 rounded-2xl
  bg-white p-2 ring-1 ring-white/30`) on brand-color gradient — already correct.
- **Subsidy live preview**: 3 bold blocks (off-white original / coral subsidy / dark
  final) using `bg-tertiary-container` + `bg-primary-container` — already bold.
- **Recon summary**: 3 bold blocks (off-white original / coral subsidy / dark final)
  — already bold.

## Verification
- `bun run lint` → exit 0 (after fixing one template-literal typo in BarChart
  tooltip formatter introduced during edit: `[`${v} chuyến", ...]` → `[`${v} chuyến`, ...]`).
- Dev server compiles cleanly (dev.log shows `✓ Compiled` with no errors).
- No remaining `bg-*-container/NN` pale-tint backgrounds in either file.
- No remaining `var(--color-chart-4/5)` oklch chart references in admin module.
- No remaining `#10b981/#14b8a6/#ec4899/#9333ea` old-palette chart fills in uni-admin.
- No remaining `var(--m3-primary)` lime stroke on light-bg charts.

## Stage Summary
- Files: src/components/bus/roles/admin-module.tsx, src/components/bus/roles/university-admin-module.tsx
- Lint: PASS (exit 0)
- Both modules now fully perk-style: bold StatCards, bold container tints, perk-palette
  recharts (#beff50/#144fcc/#ff8c5f/#c8a0ff), dark tooltips with lime text, no pale
  tint backgrounds, mobile-safe with min-w-0+truncate on all flex/grid text children.
