# Task 31 — Coordinator Module perk-style redesign + mobile fix

Agent: full-stack-developer (Coordinator perk redesign)
File: `src/components/bus/roles/coordinator-module.tsx` (3285 lines, 10 screens)

## Context
- Followed Task 28 design mandate (perk.com bold style, no pale containers).
- CSS tokens already globally updated: primary-container=#14140f (dark), secondary-container=#144fcc (blue), tertiary-container=#ff8c5f (coral), error/success/warning containers all bold.
- StatCard primitive already uses bold color blocks (dark/lime/coral/blue/red/green).
- Icon circles using `bg-primary-container` etc. already render bold via CSS tokens.

## Changes applied

### 1. Selection states — replaced pale opacity tints with solid bold lime cards
- **Live map side list** (line ~857): `bg-secondary-container/50` → `bg-secondary-container text-on-secondary-container` (solid bold blue selection row).
- **Schedule today header** (line ~1191): `bg-primary-container/30` → `bg-[#14140f] text-[#beff50]` (bold dark column header with lime text; date circle `bg-primary text-on-primary` pops on dark).
- **Schedule today body cells** (line ~1242): `bg-primary-container/15` → `bg-surface-container-lowest` (neutral subtle highlight, no pale primary tint).
- **Schedule "Phân công" buttons** (lines ~1147, ~1254): `hover:bg-primary-container/30 hover:text-on-primary-container` → `hover:bg-[#beff50] hover:text-[#14140f] hover:border-[#beff50]` (bold lime hover).
- **Assign-driver card selected** (line ~1488): `bg-primary-container/40 border-primary` → `bg-[#beff50] border-[#beff50] text-[#14140f]`. Details div made conditional: `text-[#14140f]/70` when selected (dark text on lime) vs `text-on-surface-variant` default.
- **Assign-bus card selected** (line ~1647): same bold lime treatment. Model `<p>` and details div both made conditional `text-[#14140f]/70` vs `text-on-surface-variant`.
- **By-university summary card selected** (line ~2496): `bg-primary-container/30 border-primary` → `bg-[#beff50] border-[#beff50] text-[#14140f]`. Added `min-w-0` to root.

### 2. By-university hero — pale gradient → bold dark hero
- Replaced `linear-gradient(135deg, color-mix(in oklch, ${uni.color} 25%, surface-container-high), surface-container-high)` (pale wash) with solid `bg-[#14140f]` + `borderTop: 4px solid ${uni.color}` (uni color accent stripe).
- Title `text-on-surface` → `text-[#beff50]` (lime on dark).
- Address `text-on-surface-variant` → `text-white/70`.
- Hash code chip `bg-surface-container-highest` → `bg-[#beff50] text-[#14140f]` (bold lime chip).
- 3 stat boxes (were pale `bg-surface-container/80`): now bold multi-color — Sinh viên=`bg-[#beff50]` lime, Tuyến=`bg-[#ff8c5f]` coral, Cơ sở=`bg-[#144fcc]` blue. Text colors set to dark/white for contrast. Added `tabular-nums`, `min-w-0`, `shrink-0`.

### 3. text-primary → text-[#144fcc] (subsidy text on light bg)
- Line ~2512: `<Wallet className="size-4 text-primary" />` → `text-[#144fcc]` (blue, readable on light card; primary #beff50 lime would be invisible).
- Line ~2531: `<span className="font-semibold text-primary">` → `text-[#144fcc]`.

### 4. LIVE badges — added text-white for contrast
- Dashboard live bus card LIVE badge (line ~414): added `text-white`; pulse dots changed from `bg-success` to `bg-white` (more visible on bold green #16a34a).
- Live map header LIVE badge (line ~697): same treatment.

### 5. Mobile fix — min-w-0 + truncate on flex/grid text children
- Uni trips table cell (line ~2577): `flex items-center gap-2` → `flex min-w-0 items-center gap-2`; route name span got `min-w-0 truncate`.
- Uni drivers table cell (line ~2644): avatar div got `shrink-0`; inner content div got `min-w-0`; name + phone `<p>` got `truncate`.
- By-university route card (line ~2685): ExpressiveCard got `min-w-0`; route name + from→to paragraphs got `truncate`.

## Lint
- `bun run lint` → exit 0 (no errors).

## Screens verified (10)
- crd-dashboard ✓ (StatCards already bold, live bus list bold icon chips, incidents panel bold red icon)
- crd-live ✓ (BusMap kept with parallax aurora bg, side list selection now solid blue)
- crd-schedule ✓ (today column header bold dark+lime, shift chips bold, mobile day-list kept)
- crd-assign-driver ✓ (driver cards selected=bold lime, conflict warning=bold red error-container)
- crd-assign-bus ✓ (bus cards selected=bold lime, maintenance greyed)
- crd-routes ✓ (table overflow-x-auto, route color dots bold via RouteCodeBadge)
- crd-stops ✓ (table + Sheet drawer, bold stop icons)
- crd-by-university ✓ (bold dark hero + multi-color stat blocks, summary cards bold lime selected)
- crd-feedback ✓ (StatCards bold, feedback table, detail dialog)
- crd-notify ✓ (compose form, preview card bold priority bg, recent sent table)

## Notes
- Did NOT modify BusMap/RealMap (kept parallax aurora as functional map background, not a pale card).
- Did NOT touch other files.
- No test files written.
