# Worklog — BusGO Student Bus Management System UI

Project: Hệ thống Xe Bus Sinh viên (BusGO)
Goal: Build complete UI mockup (frontend only, mock data) covering all 6 roles and ~50 use cases from SRS.

---
Task ID: 1
Agent: main (orchestrator)
Task: Set up foundation — design system, types, mock data, navigation config, shared primitives.

Work Log:
- Read SRS docx and extracted all requirements (6 modules, 50 use cases).
- Updated `src/app/globals.css` with soft emerald/teal palette on warm cream background.
- Updated `src/app/layout.tsx` (Vietnamese metadata, Sonner toaster).
- Created `src/lib/types.ts` with all domain types.
- Created `src/lib/mock-data.ts` with comprehensive mock data (users, stops, routes, buses, trips, bookings, invoices, notifications, feedback, lost items, complaints, incidents, schedules, drivers, AI suggestions).
- Created `src/components/bus/primitives.tsx` (PageHeader, StatCard, Section, EmptyState).
- Created `src/components/bus/nav-config.ts` with NAV_CONFIG for all 5 roles + role labels/descriptions.

Stage Summary:
- Foundation ready. Design tokens: emerald/teal primary, warm cream bg, rounded-2xl, soft shadows.
- Navigation structure defined for student (16), driver (8), assistant (9), coordinator (11), admin (8) screens.
- Next: build app shell + auth screens + each role module in parallel via subagents.

---
Task ID: 5
Agent: full-stack-developer (Student module)
Task: Build Student module screens (12 role-specific screens)

Work Log:
- Read worklog.md, types.ts, mock-data.ts, primitives.tsx, nav-config.ts, app-shell.tsx, common-screens.tsx, and shadcn component APIs (badge/card/dialog/tabs/etc.) to align with existing conventions.
- Verified available mock data: users, busStops, routes, buses, trips, bookings, invoices, notifications, feedbackList, lostItems, aiSuggestions, chatbotSeed, formatVND, routeById, stopById, busById, userById. Current student = users[0] (Nguyễn Minh Anh).
- Created `src/components/bus/roles/student-module.tsx` (~1500 lines, single file) with `"use client"` directive and `StudentModule({ activeId, onNavigate })` named + default export.
- Built shared sub-components: RouteBadge (colored by route.color), StarRating (interactive 5-star with hover/fill), VerticalTimeline (route stops with done/active/pending states), SoftMapCanvas (decorative illustrated map: aurora gradient bg + SVG dashed path + grid pattern + stop pins + framer-motion animated bus marker), MethodBadge & StatusBadge (Vietnamese labels with soft color tints).
- Implemented all 12 screens via switch:
  * stu-dashboard: greeting by time-of-day, 4 StatCards, upcoming bus card with ETA + journey progress, my-routes quick list, 4-tile quick actions grid, recent notifications preview (max-h-72 scroll).
  * stu-stops: search filter, decorative SoftMapCanvas header, grid of stop cards with route badges + shelter icon, click → detail dialog with next arrivals per route.
  * stu-find: from/to stop selects + time picker, results with route badge, from→to, duration/distance/frequency/fare grid, vertical timeline of stops in side panel, "Đăng ký tuyến" → toast + navigate.
  * stu-tracking: large SoftMapCanvas (h-80) with animated bus marker that interpolates between stops every 3s, pulsing live indicator, side panel with bus/driver/assistant/speed/ETA info, occupancy progress bar with contextual hint, on-bus amenities grid, stops timeline with "đã qua/đang đến/chưa đến" states.
  * stu-my-routes: prominent monthly-pass card with expiry progress, tabs (active/history), each active card has "Đổi tuyến" + "Hủy tuyến" (with confirmation dialog containing refund notice).
  * stu-history: 3 summary StatCards, route filter, table (date/route/time/fare/status) with responsive hidden columns, export button.
  * stu-ai: gradient hero card, context inputs (free time/destination/pref chips), "Phân tích" triggers 1.6s loading shimmer state then ranked results with confidence %, match-score stars, reason text, depart→eta, fare, Đăng ký/Theo dõi actions.
  * stu-chatbot: full chat UI (70vh), seeded from chatbotSeed, user/bot bubbles with avatars + timestamps, typing indicator (3 pulsing dots), quick-reply chips, mock bot responses keyword-routed (FPT/giá/SU-02/quên đồ/chào), auto-scroll via ref.
  * stu-payment: wallet balance card with gradient, Tabs (single/monthly), route select, quantity stepper or month select, 3 radio payment method cards (MoMo/VNPay/Cash), sticky order summary, payment → success toast + receipt dialog with full breakdown + "Tải PDF" action.
  * stu-invoices: 2 summary StatCards (paid/pending), status filter, table with method/status badges, click row → detail dialog with description/method/total + "Thanh toán ngay" for pending.
  * stu-feedback: Tabs (new/history), form (trip select / interactive 5-star with label / category select / textarea), tips sidebar, history list with route badge + category + star rating + status.
  * stu-lost: form sidebar (route/date/item/desc) + reports list with status timeline (4-step horizontal: reported → found → returned → closed) showing completed/pending visual states.
- Used design language throughout: emerald/teal primary via `bg-primary`/`text-primary`, warm cream bg from globals.css, rounded-2xl/xl, shadow-sm → hover:shadow-md, framer-motion subtle `initial={{opacity:0,y:8}} animate={{opacity:1,y:0}}`, max-h-* overflow-y-auto scrollbar-soft for long lists, mobile-first responsive (sm:/md:/lg:), Vietnamese text throughout.
- Used toast from sonner for all action feedback; no test files written; only modified `src/components/bus/roles/student-module.tsx` and (now) `worklog.md`.
- Ran `bun run lint` — 0 errors, 0 warnings on my file (only unrelated pre-existing warning in driver-module.tsx).
- Verified dev server log shows successful compiles after file creation.

Stage Summary:
- File: src/components/bus/roles/student-module.tsx
- Screens built: 12 — stu-dashboard, stu-stops, stu-find, stu-tracking, stu-my-routes, stu-history, stu-ai, stu-chatbot, stu-payment, stu-invoices, stu-feedback, stu-lost (plus a default placeholder fallback).
- Shared screens (stu-profile, stu-notifications, stu-support, stu-settings) intentionally NOT handled — they live in common-screens.tsx and are wired by the orchestrator.
- All maps use decorative SoftMapCanvas (gradient + SVG + pins), NOT a real map library — keeps bundle light and matches soft illustrated aesthetic.
- Lint: clean (0 errors / 0 warnings on this file).
- Ready for orchestrator to import StudentModule into app-shell's screen router.

---
Task ID: 9
Agent: full-stack-developer (Admin module)
Task: Build Admin module (6 screens)

Work Log:
- Read worklog.md and existing foundation files (types, mock-data, primitives, nav-config, common-screens, app-shell).
- Verified shadcn/ui component APIs (Table, Dialog, AlertDialog, DropdownMenu, Badge, Tabs, Select, Switch, Progress, Card, Button).
- Created `src/components/bus/roles/admin-module.tsx` exporting `AdminModule({ activeId, onNavigate })` that switches on `activeId` to render 6 screens.
- Built `DashboardScreen` (adm-dashboard, REQ-ADM-005): 4 StatCards row (Tổng người dùng / Chuyến hôm nay / Doanh thu tháng / Tỷ lệ đúng giờ); recharts AreaChart (revenue 7 days), BarChart (trips per route with route colors), PieChart (user role distribution with legend); scrollable "Hoạt động gần đây" feed (6 mock events with framer-motion stagger); "Cảnh báo hệ thống" panel (4 severity-tinted warning items).
- Built `UsersScreen` (adm-users, REQ-ADM-004 + REQ-ADM-001): search bar + role filter (5 roles + all) + status filter (active/locked/all) in a filter Card; sticky-header Table inside `max-h-[520px] overflow-y-auto scrollbar-soft`; columns: user (avatar + name + email), role badge (color-coded: sinh viên=emerald, tài xế=amber, phụ xe=teal, điều phối=violet, quản trị=rose), status badge (emerald/rose dot), created date, trips count, actions dropdown (Xem chi tiết / Khóa-Mở khóa / Đặt lại mật khẩu); AlertDialog confirmation for lock/unlock with role-aware button color; "Thêm người dùng" dialog form; detail dialog showing full user info; "showing X of Y" footer with pagination buttons.
- Built `ComplaintsScreen` (adm-complaints, REQ-ADM-002): 4 stat cards on top (Mới/Đang xử lý/Đã giải quyết/Từ chối counts); Tabs filter (all/new/processing/resolved/rejected with live counts); Table from `complaints` mock data (code/student/subject/category/priority/status/date); row click opens detail Dialog with full description + student info + optional resolution note Textarea + 3 action buttons (Đang xử lý / Đã giải quyết / Từ chối) — actions update local state and show toast.
- Built `ViolationsScreen` (adm-violations, REQ-ADM-003): combined `incidents` data + 4 mock violation entries (Dùng điện thoại khi lái, Không quét vé, Bỏ trạm, Chạy quá tốc độ) into a unified ViolationRow list; 4 StatCards (total this month / high severity / investigating / closed); small "Phân loại vi phạm" Card with horizontal bar visualization; filter Selects (severity, status); Table with code/type/route/severity/status; detail Dialog with "Đánh giá" + "Đóng" action buttons.
- Built `FareScreen` (adm-fare, REQ-ADM-007): Table of all `routes` (code/name with color dot, frequency, vé lượt, vé tháng, "Sửa" button); "Áp dụng cho tháng tiếp theo" Switch in header; edit Dialog with new fare + new pass inputs, live percentage-change indicator (rose for increase, emerald for decrease, with Percent icon), effective date input, reason textarea, apply-next-month toggle; "Lịch sử điều chỉnh" Card with 4 mock entries showing old→new (with TrendingUp/Down icons) + reason + changed-by.
- Built `NotifyScreen` (adm-notify, REQ-ADM-006): compose form (audience Select with 6 options, priority Select with info/warning/important, title Input with char counter, message Textarea with char counter, schedule toggle now/later with datetime-local input when later) + "Gửi thông báo" button with validation toasts; live preview Card showing a mobile-style notification card on a phone-like frame that updates with form values; "Thông báo đã gửi gần đây" table with 5 mock entries (title/audience/sent count/date/status badge).
- All screens use PageHeader/StatCard/Section/EmptyState from primitives, framer-motion for subtle animations, sonner `toast` for action feedback, warm cream background via global CSS, emerald/teal primary, rounded-xl/rounded-2xl cards, soft shadows, mobile-first responsive grids.
- Recharts charts use ResponsiveContainer with theme tokens (var(--primary), var(--border), var(--muted-foreground), var(--card)) for cohesive styling.
- Used `motion.tr` for table row stagger animations (kept inline because shadcn TableRow would not accept motion props cleanly).
- Ran `bun run lint` — only a pre-existing warning in `driver-module.tsx` (not my file); `admin-module.tsx` has 0 errors and 0 warnings.

Stage Summary:
- File: src/components/bus/roles/admin-module.tsx (~1.060 lines, single file, 6 screens)
- Screens built:
  · adm-dashboard — Thống kê hệ thống (REQ-ADM-005)
  · adm-users — Tài khoản người dùng (REQ-ADM-004 + REQ-ADM-001)
  · adm-complaints — Xử lý khiếu nại (REQ-ADM-002)
  · adm-violations — Báo cáo vi phạm (REQ-ADM-003)
  · adm-fare — Điều chỉnh giá vé (REQ-ADM-007)
  · adm-notify — Gửi thông báo hệ thống (REQ-ADM-006)
- Notes: Shared internal badge helpers (RoleBadge, StatusBadge, PriorityBadge, ComplaintStatusBadge, ViolationStatusBadge) ensure consistent color coding. Lock/unlock uses AlertDialog for confirmation. All long tables wrapped in `max-h-[420px|440px|520px] overflow-y-auto scrollbar-soft` with sticky TableHeader. Charts: AreaChart for revenue trend, BarChart for trips per route (per-route colors), PieChart for user distribution. Notify preview card mimics device notification UI. All user actions trigger sonner toast feedback. Profile/Notifications/Settings screens are NOT in this file — they are handled by `common-screens.tsx` per the orchestrator's note. Lint: clean for this file.

---
Task ID: 6+7
Agent: full-stack-developer (Driver + Assistant modules)
Task: Build Driver module (6 screens) + Assistant module (7 screens)

Work Log:
- Read worklog.md, types.ts, mock-data.ts, primitives.tsx, nav-config.ts, common-screens.tsx, app-shell.tsx, globals.css to understand the foundation, design language, and existing components.
- Confirmed driver u2 (Trần Hoàng Long) is assigned to bus b1, route r1 (SU-01). Today's running trip = t2 (07:15). Today's schedules = sc1 (morning) + sc4 (afternoon).
- Created `src/components/bus/roles/` directory.
- Wrote `src/components/bus/roles/driver-module.tsx` with 6 screens:
  - `drv-dashboard`: greeting, active trip highlight card (gradient header with live indicator), quick stats (chuyến/km/hành khách/doanh thu), today's schedule, next trip, route preview with horizontal timeline + pulsing current stop, rating summary.
  - `drv-schedule`: 7-day week selector with trip counts per day, mock upcoming-week trips for u2, sorted trip list with route/bus/time/status badges.
  - `drv-active` (HERO): big gradient card with status pill (running/scheduled/completed), live elapsed timer via setInterval, progress bar, big "Bắt đầu/Kết thúc chuyến" buttons (red destructive for end), vertical route timeline with pulsing current position, passenger counter, assistant contact panel, trip metrics.
  - `drv-route`: route hero with color, from→to, metrics grid, full vertical stop list with times, bus info card, custom SVG map illustration (lat/lng normalized to grid, dashed path, animated bus pin with ping).
  - `drv-history`: stats + scrollable table (date, route, time, passengers, revenue, rating from feedbackList).
  - `drv-contact`: coordinator card with avatar/call/message, recent messages list with unread indicators, compose bar.
- Wrote `src/components/bus/roles/assistant-module.tsx` with 7 screens:
  - `ast-dashboard`: trip info card (gradient), scan stats (vé đã quét / hợp lệ / lỗi), 4 quick action buttons, "Quét thử" demo button that increments valid count + toast.
  - `ast-scan`: QR viewfinder mock — dark aspect-square box with emerald grid texture, 4 L-shaped corner brackets, framer-motion scan line animating up/down with trailing gradient, center pulsing QrCode icon, "Mở camera" toggle + "Quét thử" demo, recent scan results list with valid/used/expired colored badges.
  - `ast-monthly`: lookup form (student ID input + scan button + suggestion chips), result card with gradient header showing days-left, route/owner/validity fields, "Xác nhận lên xe" button.
  - `ast-lost`: filter pills by status, two-pane layout (list + detail), animated found-item form, detail panel with "Đã tìm thấy / Đã trả / Liên hệ SV" actions.
  - `ast-incident`: quick form (type select, severity 3-button toggle, description) with toast validation, recent incidents list with severity/status badges and color-coded icons.
  - `ast-contact`: two contact cards (driver Trần Hoàng Long, coordinator Phạm Quốc Bảo) + recent messages list.
  - `ast-history`: stats + scrollable table (date, route, bus, scans, incidents).
- Extracted inline `ContactCard` to top-level `ContactPersonCard` to satisfy react-hooks/static-components rule.
- Removed unused eslint-disable + unused `today` variable in DriverSchedule.
- Ran `bun run lint` → 0 errors, 0 warnings. ✓
- Verified dev server compiles cleanly (dev.log shows ✓ Compiled messages).

Stage Summary:
- Files: src/components/bus/roles/driver-module.tsx (≈740 lines), src/components/bus/roles/assistant-module.tsx (≈760 lines)
- Screens built (13 total):
  - Driver: drv-dashboard, drv-schedule, drv-active (hero with live timer), drv-route (with SVG map), drv-history, drv-contact
  - Assistant: ast-dashboard, ast-scan (QR viewfinder mock), ast-monthly, ast-lost, ast-incident, ast-contact, ast-history
- All screens use shared primitives (PageHeader/StatCard/Section/EmptyState), shadcn/ui components, framer-motion subtle animations, sonner toasts, Vietnamese text, mobile-first responsive, emerald/teal palette.
- Hero "active trip" features live elapsed timer (setInterval), pulsing current position dot, gradient header, prominent red destructive "Kết thúc chuyến" button.
- QR scanner is a pure mock (no camera APIs) with animated scan line and grid texture.
- Lint: 0 errors, 0 warnings. Dev server compiles cleanly.
- Did NOT modify any file other than the two module files and worklog. Common screens (profile/notifications/support/settings) handled elsewhere.

---
Task ID: 8
Agent: full-stack-developer (Coordinator module)
Task: Build Coordinator module (9 screens)

Work Log:
- Read worklog.md and existing foundation (types, mock-data, primitives, nav-config).
- Reviewed app-shell.tsx, globals.css for design tokens, and available shadcn/ui components.
- Created `src/components/bus/roles/coordinator-module.tsx` with all 9 coordinator screens.
- Designed shared helpers: BusStatusBadge, DriverStatusBadge, RouteCodeBadge, Stars, shiftMeta (morning=amber / afternoon=teal / evening=violet), severityChip.
- Built screens:
  1. crd-dashboard — 4 StatCards + live bus list (occupancy progress), open incidents panel, shift distribution bars, recharts BarChart of trips per route (route-colored cells).
  2. crd-live — Hero dispatch map: soft topographic gradient + SVG grid pattern + route polylines (projected from stop coords) + pulsing bus markers + side list of active buses with filter-by-route + detail strip (plate/route/speed/ETA).
  3. crd-schedule — Weekly calendar grid (rows=buses, cols=T2–CN), shift-color chips, sticky header/left column, click empty cell → Phân công dialog, click chip → Edit dialog with delete, prev/next week navigation.
  4. crd-assign-driver — Two-column layout: driver cards (status/trips/phone/plate) + slot list needing drivers; selected-driver detail card with conflict warning; assign/unassign with toast + conflict detection.
  5. crd-assign-bus — Two-column: bus cards (maintenance greyed out & disabled) + slot list; assign/unassign with capacity hints.
  6. crd-routes — Table of routes (color badges, from→to, stops count, fare, frequency, active Switch), row click → edit dialog (fare/frequency/hours + ordered stop list with up/down reorder), "Thêm tuyến" → add dialog.
  7. crd-stops — Table with search, row click → Sheet detail drawer (mini map + routes passing through + edit/delete), row actions (info/edit/delete with AlertDialog confirm), "Thêm trạm" form dialog.
  8. crd-feedback — StatCards (new/avg rating/resolved) + filter-by-status table + detail dialog with full content, status transitions (new→processing→resolved) + reopen, notes textarea.
  9. crd-notify — Form (audience/title/body/priority/now-or-schedule) with live preview card + recent sent list (4 mock entries with priority badges).
- Ran `bun run lint` — initial error: setState inside useMemo → switched to key-based remount pattern (key={editing.id}) with useState initializer, lint passes clean.
- Verified dev.log: file compiles successfully (CoordinatorModule not yet wired into AppShell — orchestrator integrates).

Stage Summary:
- File: src/components/bus/roles/coordinator-module.tsx (~2200 lines, single "use client" module, 9 screen functions + shared helpers + dialogs).
- Screens built: crd-dashboard, crd-live, crd-schedule, crd-assign-driver, crd-assign-bus, crd-routes, crd-stops, crd-feedback, crd-notify.
- Design language honored: emerald/teal primary, warm cream bg, rounded-xl/2xl, soft shadows, framer-motion entrance animations, scrollbar-soft on long lists (max-h-80/96/420/560), Vietnamese text throughout, mobile-first responsive (lg:grid-cols-3 / lg:grid-cols-5 patterns).
- Live map uses pure CSS gradient + SVG (no map library) with projected lat/lng → % coordinates and animated ping markers.
- All user actions trigger `toast` from sonner with contextual messages.
- Lint: 0 errors, 0 warnings after fix.
- Note: The `onNavigate` prop is accepted but unused — module is self-contained (no cross-screen navigation needed within coordinator). Orchestrator should wire `<CoordinatorModule activeId={...} onNavigate={...} />` into AppShell children when role === "coordinator".

---
Task ID: 10
Agent: main (orchestrator)
Task: Wire up page.tsx orchestration, verify end-to-end with agent-browser, finalize.

Work Log:
- Built auth-screens.tsx (login/register/forgot) with brand panel + demo role quick-login buttons.
- Built app-shell.tsx (sidebar with grouped nav + role switcher card + topbar with search/notifications/user menu + mobile sheet + sticky footer via mt-auto).
- Built common-screens.tsx (Profile, Notifications, Support, Settings) shared across all roles.
- Created src/app/page.tsx orchestrator: manages authed state, role, activeId; renders AuthScreens or AppShell; routes common screens (profile/notifications/support/settings) and delegates role-specific screens to the 5 module components.
- Verified with agent-browser:
  * Auth screen renders (login form + 5 demo role buttons).
  * Student login → dashboard with 16 nav items, greeting, quick actions.
  * Navigation works (tracking, chatbot, AI, payment screens all render).
  * Role switcher expands and switches between all 5 roles.
  * Admin dashboard renders with recharts (area/bar/pie) — no errors.
  * Driver active-trip hero screen renders with live timer.
  * Assistant QR scanner mock renders with animated scan line.
  * Coordinator live dispatch map renders with bus markers.
  * Mobile viewport (390x844): sidebar collapses to hamburger sheet, content responsive.
  * Footer pushed down by long content (correct sticky behavior).
- Ran `bun run lint` → 0 errors, 0 warnings (exit 0).
- VLM (glm-4.6v) visual review confirmed: "Giao diện sạch, màu sắc hiện đại, thiết kế nhẹ nhàng không rườm rà, bố cục rõ ràng, không có lỗi vỡ layout."

Stage Summary:
- Complete UI demo delivered at `/` route covering ALL 6 modules and ~50 use cases from the SRS:
  * Common (8 use cases): login, register, forgot password, profile, change password (in profile), logout, notifications, support request.
  * Student (17 use cases): 12 role-specific screens + shared profile/notifications/support/settings.
  * Driver (6 use cases): 6 screens.
  * Assistant (7 use cases): 7 screens.
  * Coordinator (8 use cases): 9 screens.
  * Admin (7 use cases): 6 screens.
- Total: ~46 distinct screens across 5 roles, switchable via the in-app role switcher (demo feature).
- Design: soft emerald/teal palette on warm cream, rounded-2xl, soft shadows, framer-motion micro-animations, Vietnamese throughout, mobile-first responsive, sticky footer.
- All mock data (no backend). Lint clean. No runtime errors. Browser-verified.

---
Task ID: 12 (Major Overhaul — Material 3 Expressive + GSAP-style motion + University linkage)
Agent: main (orchestrator)
Task: Foundation overhaul for M3 Expressive + university feature prep.

Work Log:
- Read new docx (TomTat_TinhNang_LienKetTruong): adds University Admin actor, Google login, university detection via domain, route filtering by university, subsidized monthly passes, audit log, university management for System Admin, filter-by-university for Coordinator. MVP scope = 8 items.
- Rewrote `src/app/globals.css` → full Material 3 Expressive token system: tonal color roles (primary/secondary/tertiary containers, surface containers 5 levels, on-surface-variant), M3 shape scale (xs 8 → 2xl 32, full pill), state-layer utility, tonal elevation, M3 motion easings, Roboto Flex font vars, aurora-m3 background, glass-m3.
- Updated `src/app/layout.tsx`: Roboto Flex (variable) + Roboto Mono fonts, vietnamese subset, new metadata.
- Created `src/components/m3/primitives.tsx`: ExpressiveButton (filled/tonal/tertiary-tonal/outlined/text/elevated/error, sizes sm/md/lg/icon, spring press), ExpressiveCard (filled/outlined/elevated), Chip (assist/filter/input/suggestion), SegmentedButton, Fab/ExtendedFab, ListItem, AppBarHeadline, StatusPill, M3Progress.
- Created `src/components/m3/motion.tsx`: GSAP-style animations via framer-motion — SplitText (word-by-word clip reveal), ScrollReveal (in-view fade+translate), StaggerGroup/StaggerItem, Magnetic (magnetic hover), Counter (count-up), Marquee (infinite scroll), Parallax (useScroll), PinnedSection (sticky pin), PageTransition, Shimmer.
- Updated `src/components/bus/primitives.tsx` → M3 Expressive PageHeader (large display type), StatCard (tonal accent containers, spring hover, glow), Section, EmptyState, ExpressiveCard re-export.
- Extended `src/lib/types.ts`: added Role 'university_admin'; added University, Campus, UniversityDomain, StudentRosterEntry, ImportBatch, SubsidyPolicy, RouteUniversity, AuditLogEntry, UniversityStats types; added universityId/verificationStatus/authProvider to User.
- Extended `src/lib/mock-data.ts`: 4 universities (Duy Tân/Bách Khoa/Sư phạm/Việt-Hàn) with campuses+domains+stats; universityDomains; studentRoster (7 entries); importBatches (4); subsidyPolicies (4); routeUniversities (5 mappings); auditLogs (7); universityStats (3); universityAdmins (4); calcSubsidy() helper; added university_admin user (Đặng Thị Bích Ngọc, uni1); updated student user (universityId=uni1, VERIFIED, google auth, email @duytan.edu.vn).
- Rewrote `src/components/bus/nav-config.ts`: added ROLE_COLORS, ROLE_AVATARS exports; added 'university_admin' role with 11 nav items (dashboard, info, domains, import, roster, subsidy, stats, notify, recon, notifications, profile); added 'stu-university' (Trường của tôi) to student; added 'crd-by-university' to coordinator; added 'adm-universities', 'adm-uni-admins', 'adm-route-uni', 'adm-audit' to admin.
- Rewrote `src/components/bus/auth-screens.tsx`: GSAP-style landing — pinned hero with SplitText word reveals, scroll parallax (useScroll/useTransform), floating preview card, magnetic CTAs, university partners marquee, count-up stats; M3 Expressive login form with Google login button (primary CTA), email/password fallback, 6-role demo quick-login; register + forgot forms in M3 Expressive cards.
- Rewrote `src/components/bus/app-shell.tsx`: M3 navigation drawer with pill active indicator (layoutId animation), large brand header, rounded-full nav buttons, expressive top app bar (glass-m3, search pill, notification button, user dropdown), role switcher card with all 6 roles, mobile sheet, sticky footer.
- Rewrote `src/components/bus/common-screens.tsx` in M3 Expressive: Profile (with university + verification badges), Notifications (StaggerGroup), Support, Settings, NEW MyUniversityScreen (university hero card with gradient, verification status StatCards, route list with subsidy pricing breakdown, subsidy policy card).

Stage Summary:
- Foundation complete for M3 Expressive + GSAP motion + university feature.
- Next: parallel subagents rebuild the 5 role modules (student/driver+assistant/coordinator/admin/university-admin) in M3 Expressive style + integrate university features.

---
Task ID: 16
Agent: full-stack-developer (Admin rebuild)
Task: Rebuild Admin module (10 screens incl. 4 new university-management screens) in M3 Expressive + GSAP motion

Work Log:
- Read worklog.md (esp. Task ID 12 foundation) + agent-ctx/6+7-driver-assistant-modules.md for context.
- Read M3 foundation: globals.css (M3 tonal tokens, elev-1/2/3, state-layer, scrollbar-soft, aurora/glass utilities), src/components/m3/primitives.tsx (ExpressiveButton, ExpressiveCard, Chip, StatusPill, M3Progress, ListItem), src/components/m3/motion.tsx (SplitText, ScrollReveal, StaggerGroup/Item, Counter, Magnetic, Marquee, Parallax), src/components/bus/primitives.tsx (PageHeader, StatCard, Section, EmptyState, ExpressiveCard re-export).
- Read src/lib/mock-data.ts new university data: universities (4 unis: Duy Tân/Bách Khoa/Sư phạm/Việt-Hàn with campuses[], domains[], studentCount, routeCount, subsidyActive, status, color, logo), universityAdmins (4 admins), routeUniversities (5 mappings: r1↔uni1, r2↔uni1+uni2, r3↔uni2+uni1), auditLogs (7 entries), subsidyPolicies, universityStats, universityById helper.
- Read existing admin-module.tsx (2421 lines, pre-M3 — shadcn Button/Card, raw Tailwind color classes) for screen coverage baseline. OVERWROTE completely with M3 Expressive rebuild.
- Wrote new `src/components/bus/roles/admin-module.tsx` exporting `AdminModule({ activeId, onNavigate })` switch on 10 activeIds. ~1450 lines single file. Did NOT handle `-profile`/`-notifications` (handled by common-screens.tsx).
- Built shared M3-tonal helpers: RolePill (StatusPill tone-mapped per role incl. University Admin=primary), UserStatusPill (active=success/locked=error/pending=warning), PriorityPill (high=error/medium=warning/low=neutral), ComplaintStatusPill (new=primary/processing=warning/resolved=success/rejected=error), ViolationStatusPill (open=error/investigating=warning/closed=success), UniLogo (color box rounded-2xl with university initials), RouteColorDot (inline span with route.color).
- Screen 1 — adm-dashboard (REQ-ADM-005): SplitText title "Thống kê hệ thống" with word-by-word clip reveal; ScrollReveal subtitle; 4 StatCards in StaggerGroup with Counter (1.248 users / 113 trips / 94.6M revenue formatVND / 92% on-time); ScrollReveal charts: recharts AreaChart (7-day revenue with gradient fill), PieChart (role distribution with 5 roles incl. "Quản trị trường"), BarChart (trips per route with per-route color Cells); StaggerGroup activity feed (6 events max-h-96 scrollbar-soft with role-tinted icon tiles); "Cảnh báo hệ thống" panel with 4 warnings each StatusPill tone-coded.
- Screen 2 — adm-universities (NEW): StaggerGroup 4 StatCards (total/students/subsidized/routes-assigned with Counter); search input; sticky-header table inside max-h-[520px] scrollbar-soft of `universities` (UniLogo color box + name + code, campuses count, domains count, students count, routes count, subsidy StatusPill, status Switch toggle); "Thêm trường" Dialog (code/name/shortName/contactEmail/address); row click → detail Dialog (edit info + campuses list with MapPin + domains as Chips + add buttons); lock/unlock AlertDialog confirmation.
- Screen 3 — adm-uni-admins (NEW): 4 Counter StatCards (total/active/pending/locked); sticky-header table of `universityAdmins` (avatar initials + name + email, university StatusPill, status pill, createdAt, lastLogin, actions dropdown: Kích hoạt/Khóa AlertDialog / Đặt lại mật khẩu AlertDialog / Xóa); "Thêm University Admin" Dialog (select university + name + email).
- Screen 4 — adm-route-uni (NEW): two-pane layout — left routes list (color dot + code + name + "N trường" pill, click selects route), right universities list (UniLogo + shortName + "N tuyến" pill, click selects uni). Below: visual mapping matrix table rows=routes × cols=universities, each cell has Switch to toggle assign/unassign (updates local state + toast). Dimming applied when a route/uni is selected (other rows/cols opacity-40). Active mappings rendered as Chips below matrix (route color dot ↔ uni code).
- Screen 5 — adm-audit (NEW): 4 Counter StatCards (total/success/failure/today); filter bar (search input + role Select admin/uni_admin/coordinator + result Select success/failure); sticky-header table inside max-h-[560px] scrollbar-soft of `auditLogs` (timestamp / actor avatar with role-tinted bg + role label / action+target / university pill / result StatusPill success=success-tone/failure=error-tone / IP mono); EmptyState fallback; footer with counts.
- Screen 6 — adm-users (REQ-ADM-004 + 001): filter Card with search + role Select (incl. University Admin) + status Select; sticky-header table inside max-h-[500px] scrollbar-soft of `allUsers` (avatar initials + name + email, RolePill color-coded, UserStatusPill, createdAt, trips, actions dropdown: Xem chi tiết / Khóa-Mở khóa AlertDialog / Đặt lại MK AlertDialog); "Thêm người dùng" Dialog (name/email/role select incl. University Admin/phone); detail Dialog with info grid; pagination footer (8 per page, Trước/Sau buttons).
- Screen 7 — adm-complaints (REQ-ADM-002): 4 Counter StatCards (Mới/Đang xử lý/Đã giải quyết/Từ chối); pill Tabs (all/new/processing/resolved/rejected with live counts); sticky-header table of `complaints`; row click → detail Dialog (info grid + description + resolution Textarea + 3 action buttons: Đang xử lý outlined / Đã giải quyết tonal / Từ chối error) — actions update local state + toast.
- Screen 8 — adm-violations (REQ-ADM-003): combined `incidents` (4) + 4 mock violations (Dùng điện thoại/Không quét vé/Bỏ trạm/Chạy quá tốc độ); 4 Counter StatCards (total/high-severity/investigating/closed); "Phân loại vi phạm" Card with M3Progress horizontal bars normalized to max count (4 categories color-coded); severity + status Select filters; sticky-header table; row click → detail Dialog (info grid + description + "Đánh giá & Chuyển xử lý" button).
- Screen 9 — adm-fare (REQ-ADM-007): Table of `routes` (RouteColorDot + code + name, frequency, vé lượt formatVND, vé tháng formatVND, Sửa ExpressiveButton tonal); "Áp dụng tháng tiếp theo" Switch in PageHeader actions; edit Dialog (new fare Input + new pass Input + live % change indicator with Percent icon — rose up/emerald down — + effective date + reason Textarea + apply-next Switch); "Lịch sử điều chỉnh" Card with 4 mock entries (route + old→new formatVND + TrendingUp/Down icon + reason + date + by + Tăng/Giảm StatusPill).
- Screen 10 — adm-notify (REQ-ADM-006): compose form (audience Select with 6 options incl. "Theo trường"/"Theo campus" — conditional university Select appears when chosen; title Input with 80 char counter; message Textarea with 240 char counter; priority Select info/warning/important; schedule toggle Switch now/later with datetime-local input); live preview ExpressiveCard with phone-frame UI (rounded-[2.5rem] border-4 + status bar + notification card with priority-toned icon + audience count); "Gửi thông báo" ExpressiveButton lg full-width (validates title/message non-empty); recent sent table (5 mock entries with audience/sent count/date/status).
- All screens use M3 Expressive primitives (ExpressiveButton/ExpressiveCard/StatusPill/Chip/M3Progress) over shadcn Button/Card/Badge; tonal color roles only (no raw Tailwind color classes for badges — kept route.color for chart Cell fills since route identity colors come from mock data); rounded-xl/2xl/full shape scale; elev-1/2/3 tonal elevation; state-layer on interactive elements; spring motion via framer-motion; mobile-first responsive (grid-cols-2 → lg:grid-cols-4, sm:/lg: breakpoints); Vietnamese text throughout; warm cream bg (oklch 0.992 0.003 155) with surface-container-* layered cards.
- Ran `bun run lint` → 0 errors, 0 warnings ✓ on admin-module.tsx. (Dev log shows a separate unrelated error about missing `@/components/bus/roles/university-admin-module` — that is a different parallel task, NOT my file. My admin-module.tsx compiles clean.)

Stage Summary:
- File: src/components/bus/roles/admin-module.tsx (~1450 lines, single "use client" module, 10 screens)
- Screens built:
  · adm-dashboard — Thống kê hệ thống (REQ-ADM-005) — SplitText + Counter + ScrollReveal charts
  · adm-universities — NEW: Trường đại học đối tác
  · adm-uni-admins — NEW: Tài khoản Admin trường
  · adm-route-uni — NEW: Gán tuyến cho trường (two-pane + matrix with switches)
  · adm-audit — NEW: Audit log (filterable, color-coded result)
  · adm-users — Tài khoản người dùng (REQ-ADM-004 + 001, incl. University Admin role)
  · adm-complaints — Xử lý khiếu nại (REQ-ADM-002)
  · adm-violations — Báo cáo vi phạm (REQ-ADM-003)
  · adm-fare — Điều chỉnh giá vé (REQ-ADM-007)
  · adm-notify — Gửi thông báo (REQ-ADM-006, phone preview)
- Notes: M3 Expressive tonal palette throughout (no indigo/blue, no raw Tailwind status colors). Spring motion via framer-motion. StatusPill tones replace all raw Badge color classes. AlertDialog for all confirmations (lock/unlock/reset password). toast from sonner for all actions. Tables: sticky header + max-h + scrollbar-soft. Charts: recharts with M3 theme tokens. Mobile-first responsive. Warm cream bg with surface-container layering.
- Lint: 0 errors, 0 warnings on admin-module.tsx.
- Did NOT modify any file other than src/components/bus/roles/admin-module.tsx and worklog.md. No test files.

---
Task ID: 15
Agent: full-stack-developer (Coordinator rebuild)
Task: Rebuild Coordinator module (10 screens incl. new university filter) in M3 Expressive + GSAP motion

Work Log:
- Read worklog.md (Tasks 1, 5, 6+7, 8, 9, 10, 12) to understand foundation and prior coordinator implementation.
- Read M3 foundation: globals.css (M3 tonal tokens, aurora-m3, grid-texture, scrollbar-soft, elev-1/2/3, state-layer utilities), m3/primitives.tsx (ExpressiveButton/Card, Chip, SegmentedButton, Fab, ListItem, AppBarHeadline, StatusPill, M3Progress), m3/motion.tsx (SplitText, ScrollReveal, StaggerGroup/Item, Magnetic, Counter, Marquee, Parallax, Shimmer, PageTransition), bus/primitives.tsx (PageHeader, StatCard with tonal accents, Section, EmptyState).
- Read mock-data.ts: confirmed allBuses, allDrivers, buses, busStops, feedbackList, incidents, routes, schedules, trips, universities, universityById, universityStats, routeUniversities, formatVND, routeById, stopById, universityAdmins available. Confirmed 4 universities (Duy Tân/Bách Khoa/Sư phạm/Việt-Hàn), 5 routeUniversities mappings (r1↔uni1, r2↔uni1+uni2, r3↔uni2+uni1).
- OVERWROTE src/components/bus/roles/coordinator-module.tsx — single "use client" file, ~1700 lines, exports CoordinatorModule({ activeId, onNavigate }) that switches on activeId to render 10 screens. Does NOT handle -profile/-notifications.
- Migrated tonal color roles throughout: replaced all amber-500/teal-500/violet-500/emerald-500/rose-500 raw Tailwind classes with M3 tokens (bg-primary-container, bg-secondary-container, bg-tertiary-container, bg-success-container, bg-warning-container, bg-error-container, text-on-*-container, bg-surface-container-*).
- Replaced Badge-based status indicators with StatusPill (success/warning/error/primary/tertiary/neutral tones with dot indicator).
- Replaced shadcn Progress with M3Progress (spring-animated fill).
- Replaced shadcn Button with ExpressiveButton (filled/tonal/tertiary-tonal/outlined/text/elevated/error variants, rounded-full, spring whileTap scale 0.94).
- Replaced shadcn Card with ExpressiveCard (filled/outlined/elevated variants, rounded-xl).
- Built shared helpers in M3 style: shiftMeta (morning=primary/afternoon=tertiary/evening=secondary containers per spec), BusStatusBadge, DriverStatusBadge, RouteCodeBadge (keeps raw route.color hex for white-text legibility), Stars (tertiary fill), severityTone/severityLabel.
- Screen 1 (crd-dashboard): SplitText hero title "Tổng quan điều phối" with word-by-word spring reveal; StaggerGroup of 4 StatCards each using Counter (xe chạy X/Y, tài xế trực, tuyến X/Y, phản hồi chờ); live bus list in ExpressiveCard with M3Progress occupancy bars + StatusPill status + LIVE ping indicator; open-incidents panel with severity StatusPills; shift distribution bars with tonal colors + spring width animation; recharts BarChart trips-per-route with per-route colored Cells.
- Screen 2 (crd-live): Parallax-wrapped aurora-m3 background + grid-texture overlay; SVG route polylines projected from busStops lat/lng via project(); pulsing bus markers (animate-ping) colored by route; stop markers with primary ring; legend chip; side list of active buses with route filter Select; detail strip (4 DetailFields in grid: plate/route/speed/ETA).
- Screen 3 (crd-schedule): Weekly grid (Table) with sticky TableHeader + sticky left column; rows=buses, cols=T2–CN; today highlighted with primary-container/15; shift-color chips using shiftMeta tonal containers; prev/next/today navigation; click empty cell → AssignDialog (driver/route/shift selects with tonal shift buttons); click chip → EditSlotDialog with delete.
- Screen 4 (crd-assign-driver): Two-column layout; left = driver cards with avatar initials in secondary-container, StatusPill status, phone/plate/trips meta; right = selected-driver detail ExpressiveCard (2x2 grid of stats + conflict warning in error-container when tripsToday >= 4) + route slots list with assign/unassign buttons.
- Screen 5 (crd-assign-bus): Two-column; left = bus cards (maintenance greyed out + disabled, others clickable); right = route slots with assign/unassign; capacity hints in metadata.
- Screen 6 (crd-routes): Table of routes (code badge, name, from→to, stops count, fare, frequency, active Switch) in max-h-[560px] scrollbar-soft with sticky header; row → RouteEditDialog (fare/freq/first-last trip inputs + ordered stop list with up/down reorder buttons in primary-container numerals); "Thêm tuyến" → RouteAddDialog.
- Screen 7 (crd-stops): Searchable Table in ExpressiveCard with sticky header; row click → Sheet detail drawer (mini aurora-m3 + grid-texture map with pulsing primary marker, address card, route chips, shelter StatusPill); DropdownMenu actions (info/edit/delete); AlertDialog delete confirm; "Thêm trạm" form Dialog.
- Screen 8 (crd-by-university) NEW: Filter bar (Select university + Select campus); university hero ExpressiveCard with gradient based on uni.color + logo + stats grid; 3 StatCards with Counter (sinh viên trường / chuyến hôm nay / tài xế phục vụ trường); 3 university summary cards (clickable to switch selection, shows active students/route count/trips/subsidy); filtered trips table + drivers table (both with empty-state fallback); routes serving university grid showing campus badges + subsidy info via routeUniversities mapping.
- Screen 9 (crd-feedback): 3 StaggerGroup StatCards (new/avg rating/resolved) with Counter; Tabs filter (all/new/processing/resolved); Table with student avatar (initials in secondary-container), route badge, Stars (tertiary fill), category label, StatusPill status; row click → detail Dialog with status transitions (new→processing→resolved + reopen) + notes Textarea.
- Screen 10 (crd-notify): Compose form (audience Select incl. "Theo trường"/"Theo cơ sở" options which reveal university/campus sub-selects; title Input with counter; message Textarea with counter; priority 3-button tonal toggle; schedule now/later with datetime-local) with live preview ExpressiveCard showing device-notification frame (rounded-3xl phone mockup with tonal priority colors) + recent sent list (4 mock entries with priority StatusPills and recipient counts).
- All long tables/lists wrapped in max-h-[400-560px] overflow-y-auto scrollbar-soft with sticky TableHeader.
- Used Parallax for live map background; ScrollReveal for dashboard sections; StaggerGroup/StaggerItem for stat cards; Counter for animated numerics; SplitText for dashboard title.
- Spring motion throughout (ExpressiveButton whileTap scale 0.94, StatCard whileHover y -4, M3Progress spring width, shift bars spring width).
- toast from sonner for all action feedback (assign/unassign/edit/delete/status transitions/notify send).
- Vietnamese text throughout; mobile-first responsive (sm:/md:/lg: grid-cols patterns); rounded-xl cards, rounded-2xl hero, rounded-full buttons/chips per M3 shape scale.
- Ran `bun run lint` → initial error: missing key prop on Chip in schedule legend → added key={sh}. Re-ran → 0 errors, 0 warnings on this file. (Pre-existing dev.log error about university-admin-module.tsx missing is NOT in scope — handled by another subagent.)
- Did NOT modify any file other than src/components/bus/roles/coordinator-module.tsx and worklog.md. No test files.

Stage Summary:
- File: src/components/bus/roles/coordinator-module.tsx (~1700 lines, single "use client" module, 10 screen functions + shared M3 helpers + dialogs).
- Screens built: crd-dashboard, crd-live, crd-schedule, crd-assign-driver, crd-assign-bus, crd-routes, crd-stops, crd-by-university (NEW), crd-feedback, crd-notify.
- Design language: full M3 Expressive (tonal color roles only, no raw Tailwind colors except route.code white-text badges; rounded-xl/2xl/full shape scale; state-layer on interactive; spring motion; elev-1/2/3; aurora-m3 + grid-texture for map; scrollbar-soft on long lists; StatusPill for status; M3Progress for occupancy; ExpressiveButton/Card throughout).
- GSAP-style cues: SplitText dashboard title, StaggerGroup+Counter stat cards, Parallax live-map bg, ScrollReveal sections.
- Coordinator feel = "command center" but soft: tonal containers + rounded shapes + spring motion keep it approachable rather than corporate.
- crd-by-university wired to routeUniversities + universityStats + universities data; supports filter by university AND campus; shows 3 university summary cards + 3 stat cards + filtered trips/drivers tables + route cards with campus badges.
- Lint: 0 errors, 0 warnings on this file.
- Ready for orchestrator; onNavigate prop accepted (unused — module self-contained).

---
Task ID: 14
Agent: full-stack-developer (Driver + Assistant rebuild)
Task: Rebuild Driver (6) + Assistant (7) modules in M3 Expressive + GSAP motion

Work Log:
- Read worklog.md (esp. Task ID 12) to understand M3 Expressive foundation: globals.css tokens, m3/primitives.tsx (ExpressiveButton/Card/Chip/SegmentedButton/ListItem/StatusPill/M3Progress/Fab), m3/motion.tsx (SplitText/ScrollReveal/StaggerGroup+Item/Magnetic/Counter/Marquee/Parallax/Shimmer/PageTransition), bus/primitives.tsx (PageHeader/StatCard/Section/EmptyState/ExpressiveCard), mock-data.ts (driver u2 Trần Hoàng Long, assistant u3 Lê Thị Phương, bus b1 51B-12345, route r1 SU-01, coordinator u4 Phạm Quốc Bảo).
- Confirmed Đà Nẵng context: route r1 SU-01 maps to uni1 (Đại học Duy Tân) via routeUniversities. Embedded university info throughout ("Phục vụ sinh viên Đại học Duy Tân", active-trip hero, monthly pass result card, route hero subtitle).
- OVERWROTE src/components/bus/roles/driver-module.tsx (~1350 lines, "use client", exports DriverModule({ activeId, onNavigate })):
  * drv-dashboard — SplitText greeting by time-of-day, active-trip gradient ExpressiveCard (primary→tertiary) with live pulse + 3 stat tiles (passengers/next-stop/ETA) + Magnetic "Quản lý chuyến" CTA, 4 StaggerGroup StatCards with Counter (chuyến/km/khách/doanh thu VND), today's schedule list (ListItem with route+status pill), tertiary-container rating summary with stars, next-trip card, horizontal timeline (5 stops with pulsing current stop).
  * drv-schedule — PageHeader with week-offset prev/next icon buttons, 7-day week selector grid (Mon-Sun) with per-day trip-count badges, selected-day highlight on primary elev-1, today dot indicator, sorted trip list with route color dot + StatusPill (scheduled/running/completed/cancelled) + bus plate + assistant indicator, EmptyState for rest days, mock upcoming-week trips generated from week offset.
  * drv-active (HERO) — Gradient ExpressiveCard (primary→tertiary) with live status pill, large LIVE elapsed timer (HH:MM:SS via setInterval in useElapsed hook), progress bar (M3-style), Magnetic ExpressiveButtons: "Bắt đầu chuyến" (elevated, surface bg) and destructive "Kết thúc chuyến" (error variant) + "+1 khách" tonal button. Vertical route timeline with pulsing current position (ping animation, Locate icon), passenger counter card with +/- steppers, trip metrics grid (revenue/speed/distance/plate), secondary-container assistant contact panel with call/message. Auto-advances stop every 8s (demo). Shows university info (University icon + Đại học Duy Tân).
  * drv-route — Route hero ExpressiveCard with route.color gradient + from→to + 4 metric tiles. Two-column: vertical timeline (full stop list with computed times) + RouteMapSVG (custom SVG with normalized lat/lng projection, dashed primary path, animated ping on bus position, grid-texture + aurora backdrop, speed badge). Bus info card with 6 metrics.
  * drv-history — 4 StaggerGroup StatCards (Counter for trips/km/passengers/revenue), scrollable table (max-h-28rem scrollbar-soft) with date/route color/time/passengers/revenue/rating columns, sticky header, motion.tr row stagger, StatusPill "Đã hủy" for cancelled.
  * drv-contact — ContactPersonCard for coordinator (avatar in tertiary-container, Magnetic call/message buttons → sonner toast), BusGO Đà Nẵng info card, full chat panel (h-32rem) with bubbles, online status, compose input + Magnetic send FAB.
- OVERWROTE src/components/bus/roles/assistant-module.tsx (~1100 lines, "use client", exports AssistantModule({ activeId, onNavigate })):
  * ast-dashboard — SplitText greeting, gradient trip info card (primary→tertiary) with route/driver/university/next-stop tiles + live pulse, 3 StaggerGroup StatCards with Counter (vé đã quét / vé hợp lệ / vé lỗi), 4 quick-action tiles (Quét/Vé tháng/Đồ thất lạc/Báo sự cố) with tonal accent backgrounds, demo "Quét thử" button that increments valid count + toast, secondary-container driver contact card.
  * ast-scan — QR viewfinder mock: aspect-square dark box with grid-texture + aurora, 4 L-shaped corner brackets (border-primary), framer-motion scan line animating top 12%↔84% with trailing primary gradient + glow boxShadow, center pulsing QrCode icon (scale + ping), camera-on/off toggle (status text in pill), "Quét thử" demo adds random sample scan to list (valid/used/error states → success/warning/error toast). Recent scan list (max-h-28rem scrollbar-soft) with StatusPill (Hợp lệ=success/Đã dùng=warning/Lỗi=error) and tonal icon chips.
  * ast-monthly — Lookup form: IdCard input + Magnetic "Tra cứu" filled button + "Quét QR" tonal button + suggestion Chips (SE20A01/IT21B05/SE22A03/BA19C12). Result gradient ExpressiveCard (tertiary→primary) with ShieldCheck "VÉ THÁNG HỢP LỆ" pill, student name/code/university, Counter for days-left, 4 info tiles (route/owner/valid-from/valid-until), Magnetic "Xác nhận lên xe" elevated button → toast. EmptyState before search.
  * ast-lost — Filter Chips row (Tất cả/Mới báo/Đã tìm thấy/Đã trả/Đã đóng) with count badges. Two-pane: list (ListItem active state) + detail ExpressiveCard with status pill, 4-field grid (student/route/trip-date/report-date), description, action buttons (Đã tìm thấy/Đã trả/Liên hệ SV/Đóng hồ sơ — state-conditional). Animated found-item form (input + textarea + "Thêm đồ tìm thấy" button) appends to list + toast.
  * ast-incident — Quick form: type selector grid (5 type buttons, selected on secondary-container), severity SegmentedButton (3 options with icons), description Textarea, trip info card (route/bus/driver/assistant), Magnetic "Gửi báo cáo" filled button with validation toast. Recent incidents list (max-h-34rem scrollbar-soft) with severity-coded icon chip (high=error/medium=warning/low=success) + dual StatusPill (severity + status: open/investigating/closed), motion stagger.
  * ast-contact — Two ContactCard components (driver Trần Hoàng Long + coordinator Phạm Quốc Bảo) with Magnetic call/message buttons, BusGO Đà Nẵng info card, full chat panel with bubbles, sender-name labels for them-messages (driver=tertiary, coordinator=primary), compose input + Magnetic send FAB.
  * ast-history — 4 StaggerGroup StatCards with Counter (tổng chuyến/vé quét/TB/chuyến/sự cố), scrollable table (max-h-28rem scrollbar-soft) with date/route/plate/time/scans/incidents columns, motion.tr row stagger, StatusPill for incident count.
- All screens use M3 tonal color roles (bg-primary-container, bg-secondary-container, bg-tertiary-container, bg-surface-container-high/low, bg-error-container, text-on-surface-variant, etc.) — NO raw Tailwind colors except rare route.color accents in route hero and table dots. Shape: rounded-xl cards, rounded-2xl hero, rounded-full buttons/chips/inputs. State-layer on interactive. Spring motion { type: "spring", stiffness: 220, damping: 26 } consistently.
- GSAP-style cues implemented: SplitText (dashboard greetings), StaggerGroup+Item (StatCards), Counter (all numeric stats), Magnetic (action buttons, FAB, send buttons), ScrollReveal (every content section), PageTransition (every screen root). Active-trip hero has live pulse, scan line uses keyframe animation in framer-motion, route map has SVG animate ping.
- Used toast from sonner for every action (call/message/scan/lookup/incident-submit/lost-update/lost-add). No camera APIs (pure visual mock). Custom SVG map (no library). Live elapsed timer via setInterval in useEffect (useElapsed hook).
- Cleaned unused imports (TrendingUp, AnimatePresence, Chip, SegmentedButton, M3Progress, allDrivers, schedules, incidents, userById in driver; ChevronRight, Wallet, ArrowRight, Locate, RouteIcon, Section, formatVND in assistant). Fixed Counter `suffix` prop misuse → switched to `format` callback.
- Ran `bun run lint` — exit 0, 0 errors, 0 warnings on both files. Dev server log shows ✓ Compiled successfully (only pre-existing unrelated error is the orchestrator's missing `university-admin-module` file, not caused by my work — per task constraints I only modified my 2 module files + worklog).

Stage Summary:
- Files: src/components/bus/roles/driver-module.tsx (~1350 lines), src/components/bus/roles/assistant-module.tsx (~1100 lines)
- Screens built (13 total):
  · Driver (6): drv-dashboard, drv-schedule, drv-active (hero w/ live timer), drv-route (w/ SVG map), drv-history, drv-contact
  · Assistant (7): ast-dashboard, ast-scan (QR viewfinder mock), ast-monthly, ast-lost, ast-incident, ast-contact, ast-history
- Both modules export named + default, switch on activeId, do NOT handle -profile/-notifications (orchestrator-owned).
- M3 Expressive: tonal surfaces, large rounded shapes, state-layers, spring motion, M3Progress-style bars, gradient hero cards (primary→tertiary), tertiary-container rating panel, secondary-container assistant contact, error-container destructive buttons, success/warning/error StatusPills.
- GSAP-style: SplitText greetings, Counter stats, StaggerGroup reveal, Magnetic buttons, ScrollReveal sections, PageTransition roots, animated SVG bus pin + scan line + ping markers.
- Đà Nẵng context: Đại học Duy Tân referenced throughout (route SU-01 serves this university), BusGO Đà Nẵng contact info (254 Nguyễn Văn Linh, hotline 0236 3650 529) in both contact screens.
- Mock-only (no camera APIs, no map library, no real backend). All actions trigger sonner toasts. Lint clean.

---
Task ID: 13
Agent: full-stack-developer (Student module rebuild)
Task: Rebuild Student module in M3 Expressive + GSAP motion + university subsidy features (12 screens)

Work Log:
- Read worklog.md (esp. Task 12 — M3 Expressive overhaul foundation) and confirmed available foundation: globals.css (M3 tonal tokens, elev-1/2/3, state-layer, bg-aurora-m3, glass-m3, grid-texture, scrollbar-soft), m3/primitives.tsx (ExpressiveButton/ExpressiveCard/Chip/SegmentedButton/Fab/ListItem/AppBarHeadline/StatusPill/M3Progress), m3/motion.tsx (SplitText/ScrollReveal/StaggerGroup+StaggerItem/Magnetic/Counter/Marquee/Parallax/PinnedSection/PageTransition/Shimmer), bus/primitives.tsx (PageHeader/StatCard/Section/EmptyState/ExpressiveCard re-export), lib/types.ts (full incl. University/SubsidyPolicy/RouteUniversity), lib/mock-data.ts (incl. universities/calcSubsidy/routeUniversities/student user u1 linked to uni1 VERIFIED google).
- Wrote new `src/components/bus/roles/student-module.tsx` (~1700 lines, single "use client" file) — fully OVERWRITES the previous soft-emerald student module.
- Context constants: CURRENT_STUDENT=users[0]; STUDENT_UNIVERSITY_ID="uni1" (Duy Tân); STUDENT_UNIVERSITY=universityById; VERIFIED_BADGE check; UNI_ROUTE_IDS computed from routeUniversities (r1, r2, r3 all serve uni1) — used to highlight "Dành cho trường bạn" across stu-find / stops / payment / invoices / ai.
- Built shared M3 sub-components:
  · RouteCodeBadge — pill badge colored by route.color, white text, Bus icon, elev-1.
  · UniRouteChip — tertiary-container chip "Dành cho Duy Tân" with School icon.
  · M3StarRating — interactive 5-star with hover, lucide Star with fill, M3-toned inactive state.
  · VerticalTimeline — vertical stops timeline with done/active/pending dot states (ring-surface-container-lowest), pulsing active dot via framer-motion.
  · M3MapCanvas — decorative map (bg-aurora-m3 + grid-texture overlay + parallax soft blob + SVG dashed polyline colored by route + stop pins + animated motion.div bus marker that interpolates left/top % with pulsing halo). Height prop. Legend strip.
  · MethodPill, InvoiceStatusPill — StatusPill wrappers for payment method & invoice status.
- 12 screens built (each its own function, wrapped in PageTransition):
  1. stu-dashboard — SplitText greeting by time-of-day ("Chào buổi chiều, Anh!"); university + VERIFIED + Google chips; 4 StatCards in StaggerGroup with Counter (Tuyến đã đăng ký / Chuyến tháng này / Số dư ví / Điểm tích lũy); upcoming-bus hero ExpressiveCard (elevated, gradient) with route badge, ETA, animated journey M3Progress, magnetic "Theo dõi chuyến" CTA, decorative pulsing bus icon; my-routes quick list (clickable → stu-my-routes); 4-tile quick actions grid (Tìm tuyến / Theo dõi xe / Mua vé tháng / AI gợi ý) wrapped in Magnetic; recent notifications preview in max-h-72 scroll.
  2. stu-stops — M3 outlined search input; decorative aurora+grid map header with floating stop pins (motion.div animate y bob); grid of ExpressiveCard filled stop cards (name, code, address, route color pills, UniRouteChip if applicable, shelter icon); click → Dialog with next arrivals per route (random times).
  3. stu-find — ExpressiveCard search form (Từ/Đến selects + time picker + magnetic Tìm tuyến button); results ranked with UNI_ROUTE_IDS first (sort), each result shows RouteCodeBadge, from→to, 4-tile grid (duration/distance/frequency/fare), horizontal compact stops timeline, UniRouteChip + ring-tertiary for uni routes, "Đăng ký tuyến" ExpressiveButton (filled if uni, tonal otherwise) → toast with subsidy note + onNavigate("stu-my-routes").
  4. stu-tracking (HERO) — large M3MapCanvas (h-[420px]) with animated bus marker that interpolates between stops via setInterval (segIndex + segT), pulsing LIVE StatusPill in header; side ExpressiveCard with bus plate, model, driver/assistant, speed/ETA, occupancy M3Progress with contextual hint, amenities grid (Wifi/Máy lạnh/Cổng sạc/Nước uống); VerticalTimeline of route stops with active pulsing; contact panel in tertiary-container.
  5. stu-my-routes — Tabs (Đang hoạt động / Lịch sử); active cards: ExpressiveCard elevated with gradient header from route.color + grid-texture overlay, days-left countdown, M3Progress expiry bar, **subsidy note** when isUni (success-container card with School icon showing "Trợ giá từ Duy Tân (30%) — tiết kiệm 54.000đ mỗi tháng"); "Đổi tuyến" (Dialog with route select) + "Hủy tuyến" (AlertDialog with refund warning + error action) ExpressiveButtons; "Đăng ký tuyến mới" → onNavigate("stu-find").
  6. stu-history — 3 StatCards with Counter (Tổng số chuyến / Tổng chi tiêu / Tháng này); route filter Select + Export button (mock toast); scrollable Table (max-h-460 scrollbar-soft) with sticky header.
  7. stu-ai — gradient hero (bg-aurora-m3 + grid-texture) with tertiary-container Sparkles icon + SplitText "AI gợi ý tuyến cho bạn"; context inputs (free time / destination / 4 preference chips toggle); magnetic "Phân tích" button → 1.6s setTimeout loading state showing 3 Shimmer placeholders → ranked results from aiSuggestions (sorted by confidence); each result: RouteCodeBadge + UniRouteChip, reason callout (Info icon), confidence M3Progress + match stars (M3StarRating readOnly), fare + magnetic "Đăng ký" button → toast + onNavigate("stu-my-routes").
  8. stu-chatbot — Full chat UI (60vh message area, scrollbar-soft), seeded from chatbotSeed; bot bubbles = secondary-container rounded-bl-md, user bubbles = primary rounded-br-md, avatars (Bot icon / initials); framer-motion message entrance; typing indicator (3 pulsing dots animate opacity+y); quick reply Chips (4 suggestions); keyword-routed botReply (FPT/giá/SU-02/quên đồ/chào/lịch); auto-scroll via ref + useEffect.
  9. stu-payment (WITH SUBSIDY) — gradient wallet hero (bg-primary, Counter for balance); Tabs (Vé lượt / Vé tháng); for Vé tháng + uni route → calcSubsidy(route.monthlyPass, "uni1") breakdown card (success-container): original strikethrough / subsidy success / final primary, "Trợ giá từ Duy Tân 30%" pill; quantity stepper for vé lượt / month select for vé tháng; 3 payment method radio cards (MoMo/VNPay/Cash) as border-toggled cards; sticky lg:sticky lg:top-6 order summary with subsidy line; Pay → toast + receipt Dialog with full breakdown incl. subsidy line + "Tải biên lai" button.
  10. stu-invoices — 2 StatCards with Counter (Đã thanh toán / Chờ thanh toán); Tabs filter (all/paid/pending); scrollable Table with method/status pills; click row → Dialog with description, date, method, and **subsidy breakdown** if description contains "tháng" and route match (calcSubsidy).
  11. stu-feedback — Tabs (Gửi phản hồi / Lịch sử); form: trip select / interactive M3StarRating (32px) with live label / category chips (filter-selected when active) / Textarea with char counter / magnetic "Gửi" button (validates + toast + switches to history tab); tips sidebar (outlined card with Dot bullet list); history list filtered where studentName === "Nguyễn Minh Anh" with route badge, category pill, status pill, M3StarRating readOnly.
  12. stu-lost — Two-column: form sidebar (lg:sticky lg:top-6) with route select / date / item name / description / magnetic "Gửi" button (adds to local state + toast); reports list filtered where studentName === "Nguyễn Minh Anh", each report: ExpressiveCard with item name, route badge, date, status pill, description block, **4-step horizontal status stepper** (reported→found→returned→closed) with success-filled done steps and pulsing active step ring, contact button.
- Animation strategy (GSAP feel, tasteful): PageTransition wraps each screen; SplitText on dashboard greeting + AI hero title; StaggerGroup+StaggerItem on stat cards and result lists; ScrollReveal on below-fold sections (delay cascade); Magnetic on key CTAs (theo dõi, đăng ký, phân tích, gửi, thanh toán); Counter on all StatCard numerics; M3Progress for journey/expiry/occupancy/confidence; Shimmer for AI loading; pulsing LIVE marker + bus interpolation via setInterval+useMemo.
- Color/shape language: M3 tonal roles exclusively (bg-primary-container, bg-secondary-container, bg-tertiary-container, bg-success-container, bg-warning-container, bg-error-container, bg-surface-container-low/high/highest, text-on-surface-variant, text-on-primary/secondary/tertiary-container). rounded-2xl for cards, rounded-full for buttons/chips/pills/inputs, rounded-xl for inner panels. elev-1/2/3 for lift. state-layer on interactive. No raw Tailwind colors except route.color (inline style) for route identity.
- Long lists wrapped in max-h-* overflow-y-auto scrollbar-soft. Mobile-first responsive (grid sm:grid-cols-2 lg:grid-cols-3/4 patterns). Vietnamese throughout.
- shadcn components still used where appropriate: Input, Label, Textarea, Select, Tabs, Dialog, AlertDialog, Table, Badge (only as legacy). StatusPill/M3Progress/ExpressiveButton/ExpressiveCard/Chip preferred.
- Used `toast` from sonner for all action feedback. No test files. Only modified student-module.tsx + worklog.md.
- Ran `bun run lint` → EXIT 0 (0 errors, 0 warnings on this file).
- dev.log: file compiles cleanly (✓ Compiled in 111ms after edit). Note: pre-existing `university-admin-module` not-found error in page.tsx is unrelated to this task (orchestrator's responsibility).

Stage Summary:
- File: src/components/bus/roles/student-module.tsx (~1700 lines, single "use client" module)
- Screens built (12): stu-dashboard, stu-stops, stu-find, stu-tracking, stu-my-routes, stu-history, stu-ai, stu-chatbot, stu-payment, stu-invoices, stu-feedback, stu-lost (plus FallbackScreen for unknown ids).
- University subsidy integration:
  · stu-find highlights uni1 routes first with "Dành cho Duy Tân" chip + tertiary ring; "Đăng ký tuyến" toast mentions subsidy.
  · stu-my-routes monthly cards show success-container subsidy note ("Trợ giá từ Duy Tân 30% — tiết kiệm 54.000đ/tháng") when route serves uni1.
  · stu-payment Vé tháng tab shows calcSubsidy breakdown card (original strikethrough / subsidy success / final primary), subsidy line in sticky summary and receipt Dialog.
  · stu-invoices detail Dialog includes subsidy breakdown line when invoice is for a monthly pass on a uni1 route.
- Lint: 0 errors, 0 warnings (exit 0). Compiles cleanly. Ready for orchestrator to integrate.

---
Task ID: 17
Agent: full-stack-developer (University Admin module — NEW)
Task: Build new University Admin module (9 screens) in M3 Expressive + GSAP motion

Work Log:
- Read worklog.md (esp. Task 12 foundation overhaul) to align with M3 Expressive tokens + GSAP motion primitives.
- Read full mock-data.ts to scope data to uni1 (Duy Tân): universityById('uni1'), universityDomains (d1/d2), studentRoster (r1–r7), importBatches (ib1/ib2/ib4), subsidyPolicies (sp1/sp2), universityStats, auditLogs (filtered university==='Duy Tân' → al1/al2/al3/al4/al6 = 5 entries), routes (r1/r2/r3 reference + calcSubsidy helper).
- Read m3/primitives.tsx (ExpressiveButton, ExpressiveCard, SegmentedButton, StatusPill) and m3/motion.tsx (SplitText, ScrollReveal, StaggerGroup/Item, Magnetic, Counter, Shimmer) for proper usage.
- Read bus/primitives.tsx for PageHeader/StatCard/Section/ExpressiveCard API.
- Created `src/components/bus/roles/university-admin-module.tsx` (~1.450 lines, single "use client" file) exporting `UniversityAdminModule({ activeId, onNavigate })`.
- Built shared helpers: useUniversity/useUniStats memo hooks, RosterStatusPill, ImportStatusPill, SubsidyStatusPill, DomainStatusPill, RouteDot, FieldRow — all using M3 StatusPill tonal roles (success/warning/error/neutral/primary/tertiary).
- Implemented all 9 screens via switch:
  * uniadm-dashboard (HERO): SplitText title "Quản lý trường Duy Tân"; university hero ExpressiveCard with inline gradient from uni.color (#1a73e8); 4 StatCards in StaggerGroup + Counter (1186 / 412 / SU-01 / 12.864.000đ); recharts BarChart (passes per route, route-color cells) + LineChart (trips 7 days); StaggerGroup activity feed (5 Duy Tân audit logs with success/error icons); 4-tile quick actions grid with Magnetic hover (Quản lý domain / Import SV / Trợ giá / Gửi thông báo) → onNavigate.
  * uniadm-info: University info ExpressiveCard with edit-mode toggle (Switch for status, Inputs for fields, Save → toast); campuses section as ExpressiveCards grid (c1 DTU-M Nguyễn Văn Linh, c2 DTU-7 Lê Duẩn) with edit + delete AlertDialog; "Thêm campus" Dialog (code/name/address/lat/lng form with validation).
  * uniadm-domains: Intro ExpressiveCard in primary-container tint explaining Google login auto-identification; Table of 2 domains (duytan.edu.vn, st.duytan.edu.vn) with StatusPill + Switch (lock/unlock) + delete AlertDialog; "Thêm domain" Dialog with regex validation.
  * uniadm-import: Large dashed-border upload zone (drag-drop styled, mock upload → 1.4s Shimmer processing state → toast); "Tải template CSV" link; history table (3 batches: ib1 completed/3 errors, ib2 completed/0 errors, ib4 processing with Shimmer progress bar); row click → Dialog showing 3 mock error rows (row/studentCode/email/reason).
  * uniadm-roster: 4 StatCards (total/active/suspended/graduated with Counter); search Input + Tabs filter (Tất cả/ACTIVE/INACTIVE/GRADUATED/SUSPENDED) using shadcn Tabs with rounded-full triggers; Table of 7 students with status pills; dropdown "Cập nhật trạng thái" Dialog (Select new status + reason Textarea + audit-log notice).
  * uniadm-subsidy: 4 StatCards (active policies / 12.86M subsidy / 412 students / remaining budget calculated); Table of 2 policies (sp1 30% active, sp2 fixed expired) with type pill + status pill + edit/delete actions; "Tạo chính sách" Dialog (SegmentedButton percent/fixed + value + maxAmount + activeFrom/activeUntil); EditPolicyDialog for sp1 with key-based remount; live preview ExpressiveCard showing 180.000đ → SV trả 126.000đ (trợ 54.000đ) using calcSubsidy(180000, 'uni1') with three tonal cards (original/tertiary-subsidy/primary-final).
  * uniadm-stats: Period SegmentedButton (7d/30d/12m); 4 StatCards with Counter; recharts LineChart (30 mock points), BarChart (passes per route, route colors), PieChart (5-faculty distribution with custom legend); top-3 routes table with progress bars + Export Excel button (toast).
  * uniadm-notify: Compose form (audience Select with counts, title+counter /80, message+counter /500, priority SegmentedButton info/warning/important, schedule SegmentedButton now/later + datetime-local); live preview ExpressiveCard showing phone-style notification with university logo + StatusPill for priority; "Gửi thông báo" Magnetic ExpressiveButton (validation + toast); recent sent table (4 mock entries with sent/scheduled pills).
  * uniadm-recon: Period Selects (month 01–12 + year 2025/2024); summary ExpressiveCard with 3 tonal cards (original/subsidy/final) using Counter with VND format; detailed Table per-route (r1 SU-01 + r3 SU-03 with calcSubsidy-based breakdown, totals row); CSV/PDF export buttons (PDF wrapped in Magnetic); note card in secondary-container about reconciliation between school/bus operator/students.
- M3 Expressive rules honored: tonal color roles only (bg-primary-container / bg-tertiary-container / bg-secondary-container / bg-surface-container-* / text-on-surface-variant), rounded-xl cards / rounded-2xl hero / rounded-full buttons & chips, elev-1/2/3 tonal elevation, state-layer on all interactive elements, spring motion { type: spring, stiffness: 220, damping: 26 } throughout, mobile-first responsive grids (sm:/md:/lg:), max-h-96 overflow-y-auto scrollbar-soft on all long tables.
- GSAP-style motion cues: SplitText greeting on dashboard, StaggerGroup + Counter on all StatCard rows, ScrollReveal on each section with subtle delays, Magnetic on key CTAs (Save info / Send notify / Export PDF / quick-action tiles), Shimmer on processing import batch + upload state.
- Data scope strictly to uni1: all arrays filtered by `universityId === 'uni1'` or university==='Duy Tân'; calcSubsidy(fare, 'uni1') used for live previews.
- Used shadcn Table with sticky TableHeader inside max-h-96 scroll containers for all tables (domains, import history, roster, subsidy, top routes, recon).
- StatusPill tones mapped consistently: ACTIVE/active/completed/sent=success, INACTIVE/expired/locked=neutral/error, GRADUATED=tertiary, SUSPENDED/failed=error, draft/processing/scheduled=warning.
- Removed unused imports (FileWarning, ChevronRight, M3Progress, Chip, EmptyState, Lock, Unlock, AlertCircle, Bell) — kept file lean.
- Ran `bun run lint` → 0 errors, 0 warnings on this file. ✓
- Verified dev.log: file compiles cleanly (✓ Compiled in 111ms/112ms/119ms/120ms), GET / 200.

Stage Summary:
- File: src/components/bus/roles/university-admin-module.tsx (~1.450 lines, single "use client" module, 9 screen functions + shared helpers + 2 policy dialogs)
- Screens built (9 total):
  · uniadm-dashboard — Tổng quan trường (HERO with SplitText + gradient hero + recharts + quick actions)
  · uniadm-info — Thông tin trường & campus (edit-mode + campuses CRUD dialogs)
  · uniadm-domains — Domain email (table + lock/unlock Switch + add Dialog with regex validation)
  · uniadm-import — Import danh sách SV (upload zone with Shimmer + history + error details Dialog)
  · uniadm-roster — Trạng thái SV (StatCards + Tabs filter + status update Dialog)
  · uniadm-subsidy — Chính sách trợ giá (StatCards + policies table + create/edit Dialogs + live preview using calcSubsidy)
  · uniadm-stats — Thống kê sử dụng (SegmentedButton period + LineChart/BarChart/PieChart + top-3 routes table)
  · uniadm-notify — Gửi thông báo (compose form with counters + phone-style live preview + recent sent table)
  · uniadm-recon — Báo cáo đối soát (period Selects + summary with Counter + per-route breakdown for r1/r3 + CSV/PDF export)
- Notes: All data scoped to uni1 (Duy Tân). Shared screens uniadm-profile / uniadm-notifications intentionally NOT handled — orchestrator wires them via common-screens.tsx per Task 12 note. Lint: clean (0 errors / 0 warnings). Dev server compiles cleanly.

---
Task ID: 18
Agent: main (orchestrator)
Task: Wire-up verification + bug fix + final QA.

Work Log:
- Wired page.tsx to route all 6 roles (incl. new university_admin) + stu-university (MyUniversityScreen) + shared profile/notifications/support/settings.
- Launched 5 parallel subagents (Task 13-17) to rebuild all role modules in M3 Expressive + GSAP motion + university features. All returned clean (lint 0 errors).
- Initial agent-browser verification found a runtime error in student-module DashboardScreen: `bookings` was used but not imported. Fixed by adding `bookings` to the mock-data import block.
- Re-verified with agent-browser across all roles:
  * M3 landing: hero with SplitText word reveals, magnetic CTAs, university partners marquee, count-up stats. VLM confirms M3 feel.
  * Student: dashboard (SplitText greeting, StaggerGroup StatCards, Counter, university badge), tracking (animated bus marker), payment (subsidy breakdown using calcSubsidy), my-university (gradient hero, verification status, route list with subsidy pricing).
  * Driver: active-trip hero with live timer.
  * Assistant: QR scanner mock with animated scan line.
  * Coordinator: live dispatch map + NEW "Điều phối theo trường" filter screen.
  * Admin: dashboard charts + NEW universities table, NEW university-admins, NEW route-university assignment matrix, NEW audit log.
  * University Admin (NEW role): all 9 screens — dashboard, info/campus, domains, import (Shimmer processing), roster, subsidy (with live calcSubsidy preview), stats (recharts), notify, recon.
  * Mobile (390x844): responsive layout verified.
- VLM spot-checks on subsidy + admin-universities screens confirm clean M3 Expressive rendering, no display errors.
- Final `bun run lint` → exit 0 (0 errors, 0 warnings).

Stage Summary:
- Major overhaul COMPLETE: Material 3 Expressive design system + GSAP-style motion (SplitText, ScrollReveal, StaggerGroup, Magnetic, Counter, Marquee, Parallax, Shimmer) + NEW university-linkage feature (Google login, domain detection, route filtering by university, subsidized monthly passes, University Admin module with 9 screens, university management for System Admin with 4 new screens, audit log, coordinator university filter).
- Total: ~60 screens across 6 roles. All mock data, no backend. Lint clean. Browser-verified.

---
Task ID: 19
Agent: main (orchestrator)
Task: Major QA fixes — homepage login button, magnetic cursor bug, mobile layout, map/ETA rebuild, more M3.

Work Log:
- Investigated all reported issues via agent-browser on mobile (390px) + desktop (1440px).
- Found root causes:
  * Homepage "Đăng nhập" top nav button only called setScreen("login") without scrolling → appeared broken. FIXED: added ref + smooth scrollIntoView to #auth section.
  * Magnetic component caused "div trôi theo con trỏ" bug (cursor-follow was too aggressive + leaked). FIXED: rewrote Magnetic as a subtle hover-lift + tap-scale (no cursor tracking).
  * PageTransition used blur(6px) which flickered on low-end. FIXED: clean fade+slide, no blur.
  * Parallax warned about static container + jank on touch. FIXED: disabled on mobile (<768px), values clamp to 0.
  * TrackingScreen map (M3MapCanvas) was decorative-only with aurora bg — not polished. REBUILT entirely.
- Created new `src/components/m3/bus-map.tsx` — flat M3 tonal design (NOT 3D — 3D doesn't fit M3 Expressive):
  * Flat tonal surface layers (districts, river, park shapes via SVG)
  * Subtle grid for orientation
  * Gradient route polyline with glow underlay
  * Flat M3 stop pins (success/error/primary, ring-3 surface)
  * Pulsing halo on next-stop pin
  * Animated bus marker that interpolates along polyline by progress (0..1), with pulsing halo + direction notch
  * LIVE badge + legend (compact variant for mini-maps)
  * ETACard component — mobile-first, prominent "X phút" display, route badge, occupancy bar
- Rebuilt TrackingScreen mobile-first: ETA card on top → full-width map → bus+crew info → occupancy+amenities grid → timeline. All stacked cleanly on mobile, grid on desktop.
- Rebuilt app-shell for mobile: added M3 bottom navigation bar (5 items, pill indicator via layoutId) for <lg screens, hidden on desktop. Top app bar responsive: shows page title on mobile, search hidden until md, user avatar compact. Added pb-24 on mobile main to clear bottom nav. Footer desktop-only. iOS safe-area-inset-bottom support.
- Refined motion utils: SplitText padding fix (no descender clipping), tighter springs (420/38), removed blur from reveals, added ClipReveal (clip-path wipe, true GSAP feel).
- Verified all 6 roles on mobile (390x844) + desktop (1440x900) via agent-browser + VLM:
  * Homepage: login button scrolls to auth ✓
  * Student tracking: flat M3 map, ETA card prominent, no overflow ✓
  * Student payment/subsidy: clean ✓
  * Driver dashboard: clean ✓
  * Assistant QR: clean ✓
  * Coordinator live map: clean, no overflow ✓
  * Admin dashboard: clean ✓
  * University admin subsidy: clean, table no horizontal overflow ✓
- Final `bun run lint` → exit 0. Dev log clean.

Stage Summary:
- Homepage login button FIXED (smooth scroll to auth).
- Magnetic cursor-follow bug FIXED (replaced with hover-lift).
- Mobile layout FIXED across all roles (M3 bottom nav, responsive top bar, safe-area, pb-24).
- Map/ETA REBUILT as flat M3 tonal design (decision: flat, not 3D — fits M3 Expressive). New BusMap + ETACard components, mobile-first, polished.
- More M3: refined motion (ClipReveal, tighter springs), bottom navigation bar (M3 NavigationBar pattern), cleaner type.
- Lint clean, browser-verified on mobile + desktop.

---
Task ID: 20
Agent: main (orchestrator)
Task: Address user feedback — map rebuild, mobile back button, remove bottom nav, university logos, remove wallet.

Work Log:
- User clarified: project context is Đà Nẵng only (already the case).
- User questioned wallet + separate payment. Root cause: I had invented a "wallet" concept not in SRS. REMOVED: replaced wallet StatCard on dashboard with "Chi phí tháng này" (subsidy-aware), replaced wallet hero on payment screen with a "Trợ giá từ [trường]" hero showing subsidy amount + policy validity.
- User sent 2 reference images: (1) a flat Google-Maps-light style map with bright solid pink route line, circular pins with white center dots, clean labels; (2) a screenshot of my current broken map. REBUILT BusMap component to match reference exactly:
  * Flat light-gray base (#f8f9fa) with subtle tonal district blocks + light road lines + subtle green park circles
  * Bright solid route line (route color) with soft glow underlay — NO dashes
  * Circular stop pins with white border + white center dot (start=green, end=red, middle=route color), passed stops dimmed
  * Pulsing halo on next-stop pin
  * Bus marker = same circle style but bigger with icon, flat, white border
  * Clean white-pill LIVE badge (top-left) + legend (bottom-right) with border
  * Decision: FLAT design (not 3D) — 3D doesn't fit M3 Expressive, and matches the reference image which is flat.
- Added real Đà Nẵng university logos via image-search: Duy Tân, Bách Khoa, Sư phạm, Việt-Hàn. Added logoUrl to University type + mock data. Updated: landing marquee (real logos in white rounded containers), MyUniversityScreen hero, admin universities table/cards, university-admin dashboard hero.
- REMOVED bottom navigation bar entirely (both desktop + mobile) per user request — it was buggy and not needed. Reverted main padding to p-3/p-6/p-8 (no pb-24).
- ADDED mobile back button: on mobile top app bar, when user is NOT on the first nav item, show ArrowLeft back button (returns to first nav item / dashboard) instead of hamburger menu. When on first item, hamburger shows (opens drawer). Desktop unaffected (no back button, no hamburger).
- Reverted hero CTA buttons ("Bắt đầu miễn phí" + "Dùng thử ngay") to auto-width flex-wrap (original style) instead of full-width stacked — per user preference.
- Verified all via agent-browser + VLM on mobile (390px) + desktop (1440px): landing CTAs auto-width ✓, marquee logos real ✓, new flat map matches reference ✓, mobile back button works ✓, no bottom nav ✓, payment subsidy hero replaces wallet ✓.
- Final `bun run lint` → exit 0. Dev log clean.

Stage Summary:
- Map REBUILT as flat light style matching user's reference image (flat gray bg, bright solid route, circular pins with white center, clean labels).
- Bottom nav REMOVED (both desktop + mobile).
- Mobile back button ADDED (ArrowLeft when not on first nav item).
- Hero CTAs reverted to auto-width.
- Wallet REMOVED — replaced with subsidy-aware hero + stats.
- Real Đà Nẵng university logos added (4 schools) across landing, my-university, admin, university-admin screens.
- Lint clean, browser-verified.

---
Task ID: 22
Agent: full-stack-developer (Coordinator mobile responsive fix)
Task: Fix Coordinator module mobile responsive (live bus card, schedule calendar, charts, tables) + M3 elevation audit

Work Log:
- Read worklog.md (Tasks 12, 19, 20 context) and full coordinator-module.tsx (~3.170 lines, 10 screens).
- Verified M3 elevation audit: no `shadow-sm/md/lg/xl/2xl` classes present in coordinator-module.tsx, m3/primitives.tsx, or bus/primitives.tsx — only `elev-1/2/3` tonal elevations used. Already clean (orchestrator's prior `shadow-md` removal confirmed).
- Dashboard (`crd-dashboard`):
  * "Tình trạng xe thời gian thực" card header: added `min-w-0` to title container + `shrink-0` to LIVE badge; tightened padding to `px-4 py-4 sm:px-5`; added `truncate` to bus plate span; added `min-w-0 flex-1` + `shrink-0` to occupancy row so M3Progress + numeric label don't push width on mobile.
  * "Sự cố đang mở" card header: same `min-w-0`/`shrink-0`/`truncate` treatment; padding `px-4 sm:px-5`.
  * BarChart card: wrapper div now `min-w-0 w-full h-64`; `<ResponsiveContainer width="100%" height={256}>` (fixed numeric height instead of "100%"). Chart card is `lg:col-span-2` so it stacks to full-width on mobile (grid is `lg:grid-cols-3`).
- Schedule (`crd-schedule`) — CRITICAL rebuild for mobile:
  * Added `SegmentedButton` import from `@/components/m3/primitives`.
  * Added `mobileDay` state (init to today's key or first day of week) + `activeDayKey` fallback (so when `weekOffset` changes, falls back to today or first day of new week).
  * Built NEW mobile/tablet vertical day-by-day list (`lg:hidden`) — shows one selected day's trips per bus as cards, with day header showing "T2 ngày 14" + Hôm nay pill. Bus card has plate, model, slot count; slots show route badge + start time + driver name; empty cells have Phân công button; maintenance buses show Bảo trì.
  * Added NEW mobile day selector (`lg:hidden`): horizontally scrollable `SegmentedButton` with 7 day options (`T2 14`, `T3 15`, ...) inside `-mx-1 overflow-x-auto scrollbar-soft` wrapper.
  * Wrapped the existing 7-day × buses matrix table in `hidden lg:block` so it only renders on desktop ≥1024px. Kept the existing `overflow-x-auto overflow-y-auto scrollbar-soft max-h-[560px]` wrapper for desktop.
- Live map (`crd-live`):
  * Map canvas height: `h-[480px]` → `h-[50vh] min-h-[320px] lg:h-[480px]` (mobile uses viewport-half height).
  * Side bus list: `max-h-[420px]` → `max-h-[60vh] lg:max-h-[420px]` (mobile stretches taller).
  * Selected bus detail strip grid: `sm:grid-cols-2 lg:grid-cols-4` → `grid-cols-1 sm:grid-cols-2 lg:grid-cols-4` (explicit mobile stacking).
  * PageHeader actions flex container: added `flex-wrap` so LIVE badge + route Select wrap gracefully on narrow screens.
  * Side list bus cards: added `min-w-0` to inner flex containers + plate span so `truncate` works properly.
- Assign driver (`crd-assign-driver`) & Assign bus (`crd-assign-bus`):
  * Added `truncate` to driver name span and bus plate span (assign-driver) / bus plate span + model (assign-bus).
  * Two-column layout was already `grid gap-6 lg:grid-cols-2` (stacks on mobile). No structural change needed.
- Tables — wrapped all 5 tables with horizontal scroll wrapper per spec:
  * RoutesScreen table: wrapper → `-mx-4 overflow-x-auto overflow-y-auto scrollbar-soft max-h-[560px] sm:mx-0`; `<Table className="min-w-[640px]">`.
  * StopsScreen table: wrapper → `-mx-4 overflow-x-auto overflow-y-auto scrollbar-soft max-h-[520px] sm:mx-0`; `<Table className="min-w-[640px]">`.
  * ByUniversity trips table (inside card with header): wrapper → `-mx-4 overflow-x-auto overflow-y-auto scrollbar-soft max-h-[400px] sm:mx-0`; `<Table className="min-w-[480px]">` (narrower since fewer columns).
  * ByUniversity drivers table (inside card with header): same as trips.
  * FeedbackScreen table: wrapper → `-mx-4 overflow-x-auto overflow-y-auto scrollbar-soft max-h-[520px] sm:mx-0`; `<Table className="min-w-[640px]">`.
- ByUniversity (`crd-by-university`):
  * University summary cards grid: `md:grid-cols-3` → `grid-cols-1 sm:grid-cols-2 lg:grid-cols-3` (proper mobile-first collapse).
  * University hero card: padding `p-6` → `p-4 sm:p-6`; added `min-w-0` to inner flex containers + `shrink-0` to logo; added `truncate` to uni name + address; tightened stats grid gap `gap-3 sm:gap-4` → `gap-2 sm:gap-4`.
  * University summary card button: logo+shortName row already had `min-w-0 flex-1` + `truncate` (verified, no change needed).
- Notify (`crd-notify`):
  * Recent sent list item: added `min-w-0 flex-1` to title `<p>` so `line-clamp-1` truncates properly when StatusPill is shown alongside; metadata row `flex items-center gap-2` → `flex flex-wrap items-center gap-x-2 gap-y-0.5` for mobile wrap.
  * Compose form grid was already `lg:grid-cols-5` with `lg:col-span-3`/`lg:col-span-2` (stacks to 1 col on mobile). Preview card uses `mx-auto max-w-[280px]` which is mobile-friendly. No structural change needed.
- Touch targets: icon-sm buttons (size-10 = 40px) used in schedule nav, table row actions, stops dropdown. These are slightly under 44px but consistent with M3 Expressive density pattern across the app (orchestrator-approved in Tasks 12/19/20). Did not inflate to avoid visual inconsistency with other role modules.
- M3 Expressive constraints honored: tonal color roles only (bg-primary-container / bg-secondary-container / bg-tertiary-container / bg-error-container / bg-success-container / bg-surface-container-* / text-on-surface-variant); rounded-xl/2xl/full shapes; elev-1/2/3 only (no shadow-*); state-layer on interactive elements; Vietnamese UI; scrollbar-soft on all scroll containers.
- Ran `bun run lint` → exit 0 (0 errors, 0 warnings).
- Verified dev.log: compiles cleanly (✓ Compiled in 136ms–525ms), GET / 200.

Stage Summary:
- File: src/components/bus/roles/coordinator-module.tsx (only file modified, ~3.285 lines after edits)
- Fixes:
  · Dashboard live bus card: header min-w-0/shrink-0/truncate, plate truncate, M3Progress min-w-0
  · Dashboard BarChart: fixed height={256}, min-w-0 wrapper
  · Dashboard incidents card: header min-w-0/shrink-0/truncate
  · Schedule screen: NEW mobile day-by-day vertical list (lg:hidden) + SegmentedButton day selector + matrix hidden on mobile (lg:block only)
  · Live map: h-[50vh] min-h-[320px] lg:h-[480px] + side list max-h-[60vh] lg:max-h-[420px] + detail strip grid-cols-1 on mobile + actions flex-wrap + side list min-w-0
  · Assign driver/bus: truncate on driver name / bus plate / model spans
  · 5 tables wrapped with `-mx-4 overflow-x-auto overflow-y-auto scrollbar-soft max-h-XX sm:mx-0` + `min-w-[640px]`/`min-w-[480px]`
  · ByUniversity summary grid: grid-cols-1 sm:grid-cols-2 lg:grid-cols-3
  · ByUniversity hero card: p-4 sm:p-6 + min-w-0 + truncate on name/address
  · Notify recent sent: min-w-0 flex-1 on title + flex-wrap on metadata
- Lint: 0 errors, 0 warnings. Dev server compiles cleanly.

---
Task ID: 21
Agent: full-stack-developer (Admin mobile responsive fix)
Task: Fix Admin module mobile responsive (charts overflow, tables, grids) + M3 elevation audit

Work Log:
- Read worklog.md (Task 12/19/20 context) + admin-module.tsx (2525 lines, 10 screens).
- Audited file: no non-M3 shadows (shadow-sm/md/lg/xl/2xl) found — already clean. elev-1/2/3 + tonal surfaces used throughout.
- Dashboard charts (AreaChart revenue, PieChart role-distribution, BarChart trips-per-route): all already had ResponsiveContainer width="100%" + fixed height (260/220/260). Added `min-w-0` to all 4 ScrollReveal grid-children (2× lg:col-span-2, 2× delay={0.08}) so grid cells can shrink below chart intrinsic width on mobile → no horizontal page scroll.
- Tables (8 total: Universities, UniAdmins, Audit, Users, Complaints, Violations, Fare, Notify): added `overflow-x-auto` alongside existing `overflow-y-auto` on every table scroll container (`max-h-[520px]`, `max-h-[560px]`, `max-h-[500px]`, `max-h-[460px]`, `max-h-[420px]`). Tables already had min-w on key TableHead cells (260/280/220/200/160/140px) so columns don't crush — they scroll horizontally inside the card on mobile. Verified the replace_all pattern did NOT touch the DialogContent (max-h-[85vh]) or list panes (pr-1 suffix).
- Touch targets: upgraded all 3 dropdown-menu trigger buttons (MoreVertical in Universities, UniAdmins, Users tables) from `size-9` (36px) → `size-11` (44px) to meet M3 mobile touch-target minimum. Pattern replaced via replace_all on the full className string.
- Universities search header: was `flex items-center justify-between` with fixed `w-48` search input — on 390px mobile the title + 192px input overflowed. Refactored to `flex-col sm:flex-row sm:items-center sm:justify-between`, search wrapper `flex-1 sm:w-48`, Input `w-full` → stacks vertically on mobile (full-width search), horizontal on sm+.
- Route↔University matrix (`adm-route-uni`): was a wide 4×4 matrix table with `min-w-[640px]` — forced horizontal scroll on mobile which is poor UX. Added a NEW mobile stacked view (`sm:hidden`): one rounded card per route, each listing all 4 universities with logo + name + Switch toggle, rows `min-h-11` (44px touch) with `state-layer`. Matrix table hidden on mobile (`hidden sm:block`), still shown on sm+ with horizontal scroll fallback. Summary chips section unchanged.
- Complaints TabsList (5 tabs: Tất cả / Mới / Đang xử lý / Đã giải quyết / Từ chối): total content ~430px overflowed 390px mobile. Wrapped TabsList in `<div className="overflow-x-auto scrollbar-soft pb-1">` so tabs scroll horizontally on mobile, full width on desktop.
- M3 elevation audit: confirmed zero non-M3 shadows. elev-1/2/3 + bg-surface-container-low/high/highest tonal surfaces already used everywhere. No changes needed.
- Ran `bun run lint` → exit 0, no errors. Dev log: ✓ Compiled cleanly.

Stage Summary:
- File: src/components/bus/roles/admin-module.tsx (only file modified)
- Fixes:
  * Dashboard: min-w-0 on 4 chart ScrollReveal grid children → charts no longer force horizontal page scroll on mobile.
  * 8 tables: overflow-x-auto added to scroll containers → tables scroll horizontally inside cards on mobile (no page-level horizontal scroll).
  * 3 dropdown triggers: size-9 → size-11 (44px touch target).
  * Universities search header: responsive flex-col→sm:flex-row, full-width search on mobile.
  * Route↔Uni matrix: NEW mobile stacked card view (sm:hidden) + matrix hidden on mobile (hidden sm:block) — mobile users get a touch-friendly per-route accordion instead of a wide matrix.
  * Complaints tabs: wrapped in horizontal scroll container for mobile.
  * M3 elevation: already clean (no non-M3 shadows), no changes.
- Lint: PASS (exit 0, no errors/warnings)

---
Task ID: 23
Agent: main (orchestrator)
Task: ETA/Tracking screen rebuild (Laws of UX) + mobile responsive fixes + M3 elevation audit.

Work Log:
- Researched lawsofux.com principles: Fitts's Law, Hick's Law, Jakob's Law, Law of Proximity, Law of Common Region, Von Restorff Effect, Serial Position Effect, Aesthetic-Usability Effect, Doherty Threshold, Miller's Law, Goal-Gradient Effect.
- Audited current state via agent-browser + VLM on mobile (390px):
  * Tracking screen: hierarchy weak, ETA not prominent, touch targets small, amenity icons too small.
  * Admin dashboard: charts overflow horizontally, cards break layout.
  * Coordinator dashboard: "Tình trạng xe" card breaks layout, schedule matrix too wide for mobile.
- Audited M3 elevation: only 1 shadow-md in coordinator (fixed), elev-* utilities were OK but made them more M3-authentic (subtler shadows, dark-mode aware, M3 prefers tonal surfaces over shadows).
- REBUILT TrackingScreen (student module) with Laws of UX applied:
  * Fitts's Law: huge ETA number (text-5xl/6xl), big h-14 action buttons at bottom.
  * Von Restorff: route-colored hero ETA card stands out from rest; sticky LIVE status bar with pulsing dot.
  * Law of Proximity: ETA + next stop grouped in hero card; route code + plate + model chunked together (Miller's Law).
  * Serial Position Effect: ETA at top (first), action buttons at bottom (last) — most memorable positions.
  * Jakob's Law: familiar transit-app layout (status bar → ETA hero → map → info cards → actions).
  * Goal-Gradient Effect: journey progress bar showing how far along the route.
  * Aesthetic-Usability: route-colored hero with subtle decorative blobs, spring animations.
  * Doherty Threshold: all transitions <400ms spring physics.
  * Law of Common Region: each info cluster in its own card (InfoCell component for crew grid).
  * Removed separate ETACard — integrated into hero for stronger hierarchy.
  * Added 2 big action buttons (Gọi tài xế / Chỉ đường ra trạm) at bottom — Fitts + Serial Position.
- Updated globals.css elev-* utilities: subtler shadows (0.05-0.08 opacity), added dark-mode variants. M3 prefers tonal surface containers; shadows are minimal accent.
- Removed last shadow-md in coordinator-module (replaced with elev-1).
- Launched 2 parallel subagents:
  * Task 21 (Admin): fixed charts overflow (added min-w-0 to grid children), all 8 tables get overflow-x-auto, route↔university matrix rebuilt as stacked mobile view, dropdown triggers upgraded to 44px touch targets, complaints TabsList scrollable, search header responsive.
  * Task 22 (Coordinator): fixed live bus card (min-w-0 cascade + truncate), BarChart height fixed, schedule calendar rebuilt as mobile day-by-day vertical list with SegmentedButton day selector, live map height responsive (50vh mobile), assign screens truncate names, all 5 tables get overflow-x-auto + min-w, ByUniversity grids collapse cleanly, notify list truncates.
- Verified via agent-browser + VLM on mobile (390px) + desktop (1440px):
  * Tracking new: hero ETA prominent, map flat M3 clean, no overflow, touch targets OK ✓
  * Admin dashboard: charts no longer overflow, cards clean ✓
  * Coordinator dashboard: live bus card no longer breaks, charts clean ✓
  * Coordinator schedule: mobile day-selector + vertical list works ✓
  * Assistant QR: clean ✓
  * University admin: clean ✓
  * Desktop tracking: balanced layout ✓
- Final `bun run lint` → exit 0. Dev log clean.

Stage Summary:
- Tracking screen REBUILT with Laws of UX — premium UX, route-colored hero ETA, sticky live bar, journey progress, big action buttons, chunked info.
- Admin + Coordinator mobile responsive FIXED — no more horizontal overflow, tables scroll, charts responsive, schedule rebuilt for mobile.
- M3 elevation audited — shadows subtler + dark-mode aware, only elev-* used (tonal surfaces primary).
- Lint clean, browser-verified on mobile + desktop.

---
Task ID: 24
Agent: main (orchestrator)
Task: Full Đà Nẵng data overhaul + BusMap rebuild (fix self-crossing/overlap/label-cover).

Work Log:
- User feedback: map still has rendering bugs (route self-crossing, stop overlap, bus marker covers labels) + wants ALL data updated to Đà Nẵng real locations + UX research applied freely (not just patching).
- AUDITED mock-data: discovered stops/routes/buses were still TP.HCM (Thủ Đức, FPT, VCM-td, KTX-A, 51B- plates, SU-01..04 route codes) while universities were Đà Nẵng — inconsistent. User was right.
- FULL DATA OVERHAUL to Đà Nẵng real locations:
  * 12 bus stops: ĐH Duy Tân (NVL + Lê Duẩn), ĐH Bách Khoa (Hòa Khánh), ĐH Sư phạm (Tôn Đức Thắng), ĐH Việt-Hàn (Trần Đại Nghĩa), KTX Liên Chiểu, Bến xe Trung tâm Đà Nẵng, Bến xe Điện Nam-Điện Ngọc, Vincom Bạch Đằng, Lotte Mart Hùng Vương, Sân bay Quốc tế Đà Nẵng, Bãi biển Mỹ Khê — all with real lat/lng.
  * 4 routes: DN-01 (Duy Tân→Lotte), DN-02 (Duy Tân→Bách Khoa), DN-03 (Bách Khoa→Sư phạm), DN-04 (Việt-Hàn→Mỹ Khê) with realistic distances/durations/fares.
  * 6 buses: plates changed 51B- → 43B- (Đà Nẵng), lat/lng at Đà Nẵng.
  * Updated all SUs/incidents/schedules/drivers/allBuses/aiSuggestions/feedback/lostItems/complaints/auditLogs/universityStats: SU-0X→DN-0X, 51B-→43B-, FPT→Duy Tân, KTX-A→KTX-LC, Linh Trung→Lê Duẩn, route names updated.
  * Updated all email domains: @st.edu.vn→@duytan.edu.vn, @bus.edu.vn→@busgo.dn.edu.vn.
  * Bulk sed across all role modules (admin, coordinator, driver, assistant, university-admin, student) — verified 0 remaining SU-/51B- references except a placeholder.
- REBUILT BusMap component from scratch (đập hoàn toàn):
  * Aspect-ratio-preserving projection (was distorted — lat/lng squashed) — uses cos(latitude) to correct for Đà Nẵng's ~16°N.
  * Anti-collision: spreadPoints() nudges consecutive stops apart if <5% apart, prevents pin overlap.
  * Smooth curved path: Catmull-Rom → cubic bezier (smoothPath()) — no more jagged self-crossing lines.
  * Smart label placement: labelOffset() positions labels start/end/above/below based on stop index, avoids bus marker overlap. Only shows labels for start/end/next-stop on mobile (reduce clutter).
  * Bus marker z-30 (above pins z-10), labels positioned outside the pin so never covered.
  * Flat M3 light style preserved (light gray bg, district blocks, subtle roads, park patches, white-pill badges).
- Verified via agent-browser + VLM on desktop + mobile:
  * Tracking screen: route no self-crossing ✓, stops no overlap ✓, bus marker no label cover ✓, smooth curved route ✓, premium feel ✓.
  * Mobile tracking: clean, hero ETA prominent, map no errors ✓.
  * Stops screen: all 12 Đà Nẵng stops visible (Duy Tân, Bách Khoa, Sư phạm, VKU, Lotte, Sân bay Đà Nẵng) ✓.
  * Coordinator dashboard: DN-01/DN-02/DN-03, 43B- plates visible ✓.
- Final `bun run lint` → exit 0. Dev log clean.

Stage Summary:
- ALL project data now consistently Đà Nẵng (stops, routes, buses, plates, emails, route codes, incidents, schedules, feedback, audit logs).
- BusMap REBUILT — no more self-crossing, overlap, or label-cover bugs. Smooth curved routes, smart label placement, aspect-ratio-correct projection.
- Lint clean, browser-verified on mobile + desktop.

---
Task ID: 25
Agent: main (orchestrator)
Task: Apply perk.com-inspired color palette to student role (trial).

Work Log:
- User likes perk.com color palette — wants it tried on the student role.
- Researched perk.com palette via curl + VLM:
  * Off-black #14140f (warm near-black)
  * Off-white #f5f5eb (warm ivory background)
  * Perk green #beff50 / #1dc479 (vibrant lime — primary)
  * Perk blue #144fcc (secondary)
  * Cream #fff7e5 (tertiary warm)
  * Playful multicolor accents: coral #ff8c5f, sky #82dcfa, pink #fab5fa, purple #c8a0ff
  * Mood: playful yet professional, fresh, energetic
- Implemented as a SCOPED theme override (does NOT affect other roles):
  * Added `data-role-theme={role}` attribute on AppShell root div.
  * Added CSS block in globals.css: `[data-role-theme="student"] { ... }` overrides M3 tonal tokens:
    - Primary → perk lime green (oklch 0.88 0.21 122)
    - Secondary → perk blue (oklch 0.50 0.18 255)
    - Tertiary → warm cream-yellow (oklch 0.85 0.10 85)
    - Background → warm off-white (oklch 0.985 0.008 95) instead of cool cream
    - Outlines → warm gray
  * Added playful accent utility classes (perk-coral/sky/pink/purple/cream) for chips/badges.
- Because student's ROLE_COLOR = "bg-primary" (CSS var), avatar/accents auto-pick perk green — no component changes needed.
- Verified via agent-browser + VLM:
  * Student dashboard: primary lime green ✓, secondary blue ✓, off-white warm bg ✓, playful fresh feel ✓, no errors ✓
  * Student tracking: hero ETA card perk green ✓, map route line lime ✓
  * Student payment: tertiary cream-yellow subsidy hero ✓, perk green buttons ✓
  * Role switch to Driver: reverts to default M3 emerald (NOT perk lime) ✓ — scoped theme works correctly
- Final `bun run lint` → exit 0.

Stage Summary:
- Perk.com-inspired palette applied to STUDENT role only via scoped CSS variable override.
- Other roles (driver/assistant/coordinator/admin/university_admin) keep default M3 emerald/teal — unaffected.
- Theme is token-based (no component edits), so all M3 components automatically pick up the new palette.
- Lint clean, browser-verified. User can compare by switching roles.

---
Task ID: 26
Agent: main (orchestrator)
Task: Fix perk color (too pale), real map (Grab-style), counter layout break, deeper UX.

Work Log:
- User feedback: perk green too pale (I used oklch desaturated), wants real map like Grab with simulation, counter breaks mobile layout (jumps to 6-7 digits), UX principles not truly applied.
- Fixed perk green: changed --m3-primary from oklch(0.88 0.21 122) to actual #beff50 hex (vibrant lime, not desaturated). on-primary = #14140f (perk off-black).
- Fixed Counter component: added fontVariantNumeric: tabular-nums (fixed-width digits) + minWidth based on final formatted string length (reserves space so "0" → "126.000" doesn't shift layout).
- Implemented REAL map via Leaflet + OpenStreetMap (Grab-style):
  * Installed leaflet + @types/leaflet (no API key, free tiles).
  * Created src/components/m3/real-map.tsx — RealMap component:
    - Real OSM tiles (streets, roads, buildings)
    - Custom divIcon markers (flat colored circles with white center, like the reference)
    - Route polyline on real map (glow underlay + main line)
    - Animated bus marker interpolating between real lat/lng stops
    - Auto-fit bounds to route with padding
    - zoomControl bottom-right, scrollWheelZoom off (mobile-friendly)
  * Replaced BusMap with RealMap in student TrackingScreen.
- Verified via agent-browser + VLM: real OSM map renders ✓, bus marker on map ✓, perk green vibrant #beff50 ✓, counter no longer breaks layout ✓.

UX REPORT — honest assessment of Laws of UX application:
Genuinely applied:
- Fitts's Law (bigger targets faster): h-14 action buttons on tracking, 44px touch targets, big ETA number.
- Law of Proximity: ETA + next stop grouped in hero card.
- Law of Common Region: InfoCell cards for crew grid, each cluster in own card.
- Von Restorff Effect: route-colored hero ETA stands out from rest of page.
- Serial Position Effect: ETA at top, action buttons at bottom.
- Miller's Law (7±2 chunks): route code + plate + model chunked together.
- Goal-Gradient Effect: journey progress bar showing route progress.
- Doherty Threshold (<400ms): spring physics on all transitions.
- Aesthetic-Usability: route-colored hero + decorative blobs + smooth animations.

Applied superficially / needs deeper work:
- Hick's Law (fewer choices faster): student has 17 nav items — too many. Grouped but not reduced. Should promote top 4-5 features.
- Jakob's Law (familiar patterns): used transit-app layout, now real map (Grab-like) — better.

NOT yet applied:
- Tesler's Law (complexity conservation): app has inherent complexity (6 roles, 50+ features) — not simplified for user.
- Pareto Principle (80/20): quick actions exist but not prioritized aggressively enough.
- Parkinson's Law (work expands to fill time): no time-boxing patterns.
- Postel's Law (liberal in acceptance): form validation not lenient yet.

Stage Summary:
- Perk green fixed to vibrant #beff50.
- Real map (Leaflet + OSM) implemented Grab-style with animated bus marker on real Đà Nẵng streets.
- Counter fixed — tabular-nums + reserved width, no more layout break.
- Honest UX report written above — some principles genuinely applied, some still surface-level.
- Lint clean, browser-verified.

---
Task ID: 27
Agent: main (orchestrator)
Task: Fix perk green (really #beff50), real map SSR bug + tracking layout, perf.

Work Log:
- User frustrated: perk green still not #beff50, tracking map broken, wants smoother animations, perf for weak machines.
- Verified via agent-browser: --m3-primary IS #beff50 (computed rgb(190,255,80)) — but user may have seen the tonal primary-container (pale) in some places. Confirmed button bg-primary = rgb(190,255,80) = #beff50. The vibrant lime IS applied.
- Real map was broken: Leaflet import at module top → ReferenceError: window is not defined (SSR). FIXED: dynamic import inside useEffect via loadLeaflet() helper, stash Lmod on mapRef._L for later effects. Icon helpers now take Lmod param.
- Stop coordinates overlap: s2 DTU-LD and s9 VCM were 132m apart → markers overlapped, route line self-crossed. FIXED: spread coordinates across Đà Nẵng (s2 lng 108.1300, s9 lng 108.1280 but lat different 16.0710 vs 16.0686, s10/s11 also spread). Now stops are 1-3km apart, route line clean.
- TrackingScreen REBUILT layout (no overlap):
  * Removed sticky status bar (was overlapping hero card).
  * Hero ETA card compact: 3-column flex (LIVE+route+plate | ETA big number center | speed+circular progress ring right). No sticky, no overlap.
  * Circular progress ring (SVG strokeDashoffset animated) — Goal-Gradient, more delightful than linear bar.
  * Real map below, full width, last-update badge floating top-right.
  * Mobile: height 340, desktop 420.
- Performance optimizations for weak machines:
  * RealMap wrapped in React.memo (no re-render on parent state changes).
  * Leaflet layers cleared/rebuilt only when stops/routeColor/nextStopIndex change (not on progress tick).
  * Bus marker animation = lightweight setLatLng only (no DOM rebuild).
  * preferCanvas: true on Leaflet map (canvas renderer faster than SVG for many markers).
  * willChange: transform on decorative blobs (GPU compositing hint).
  * tabular-nums on ETA number (no layout shift during animation).
- Verified via agent-browser + VLM on desktop + mobile:
  * Real street map visible ✓, 6 colored stop markers (green start, red end, lime middle) ✓, bus marker (lime circle + bus icon) ✓, route line connecting stops ✓, no overlap ✓, mobile layout clean ✓.
  * perk green #beff50 confirmed on buttons ✓.
- Lint exit 0.

Stage Summary:
- Real map (Leaflet + OSM) works Grab-style: real Đà Nẵng streets, colored pins, animated bus marker, route polyline.
- Tracking layout rebuilt — no overlap, compact hero with circular progress ring.
- Stop coordinates spread to avoid marker overlap.
- Perf: React.memo, canvas renderer, lightweight bus animation, willChange hints.
- perk green #beff50 confirmed applied.

---
Task ID: 28
Agent: main (orchestrator)
Task: Full perk-style redesign — kill pale tonal containers, mobile overflow, nav animation, homepage cleanup, register page.

Design mandate (apply to ALL roles/screens):
- PALETTE (bold, no pale): primary=#beff50 lime, on-primary=#14140f, primary-container=#14140f (off-black, NOT pale), on-primary-container=#beff50, secondary=#144fcc blue, tertiary=#ff8c5f coral, error=#dc2626, success=#16a34a, warning=#f59e0b. Background=off-white warm #f5f5eb-ish.
- AVOID: any pale/light-green tints like #e8ffa3, rgb(232,255,163), pastel containers. Containers are BOLD (dark or saturated), not washed out.
- Card backgrounds: off-white #faf8f3 / surface-container-low, OR bold color blocks (dark/blue/coral/purple) for accent cards. NOT pale-green containers.
- StatCards: bold color blocks (dark/lime/coral/blue/purple) like the student dashboard, NOT pale tonal.
- Icons on accent backgrounds: use contrasting color (lime icon on dark bg, dark icon on lime bg, etc).
- Mobile overflow: every flex/grid child with text MUST have min-w-0 + truncate where needed. Root wrapper has overflow-x-hidden.
- Nav animation: smooth spring pill indicator (layoutId), hover lift on items.
- Homepage: remove vague/marketing text, keep concise.
- Add separate /register page (or distinct register screen accessible from homepage).

CSS tokens updated (globals.css):
- primary-container: #14140f (was #e8ffa3 pale) — now bold dark
- secondary-container: #144fcc (was pale blue) — bold
- tertiary-container: #ff8c5f (was pale cream) — bold coral
- error/success/warning containers: bold (was pale)
- This means all `bg-primary-container` etc now render BOLD automatically across the app.

Subagents dispatched (parallel):
- Task 29: redesign common-screens (Profile/Notifications/Support/Settings/MyUniversity) perk-style
- Task 30: redesign Driver + Assistant modules perk-style + mobile fix
- Task 31: redesign Coordinator module perk-style + mobile fix
- Task 32: redesign Admin + University-Admin modules perk-style + mobile fix
- Main handles: auth-screens (homepage + register), app-shell nav animation, primitives, verification

Stage Summary:
- CSS tokens redefined to kill all pale containers globally.
- Dispatching parallel redesign tasks.

---
Task ID: 29
Agent: full-stack-developer (common-screens perk redesign)
Task: Redesign Profile/Notifications/Support/Settings/MyUniversity perk-style + mobile fix

Work Log:
- Read worklog Task 28 mandate + current common-screens.tsx + primitives.tsx + globals.css to understand scope. Discovered perk CSS tokens are scoped ONLY to `[data-role-theme="student"]`; default `:root` tokens are still pale M3. Because common-screens render across ALL roles (ProfileScreen takes a `role` prop), I used **literal hex colors** (`bg-[#14140f]`, `text-[#beff50]`, `bg-[#144fcc]`, `bg-[#16a34a]`, `bg-[#ff8c5f]`, `bg-[#dc2626]`, `bg-[#f59e0b]`) instead of `bg-primary-container` etc. — guarantees perk-style bold rendering everywhere, not just student scope.
- ProfileScreen: rewrote ROLE_COLORS as `{bg,fg}` map with literal hex per role (student #beff50/#14140f, driver #ff8c5f/#14140f, assistant #144fcc/#fff, coordinator #c8a0ff/#14140f, admin #dc2626/#fff, university_admin #144fcc/#fff). Avatar fallback uses inline style with these. Camera button → `bg-[#beff50] text-[#14140f]`. Verification badges → bold pills (dark+lime role pill / lime+dark verified pill with BadgeCheck icon / blue+white Google pill). Info card → `bg-surface-container-low`. Security section rebuilt as **dark accent card** `bg-[#14140f] text-white` with lime icon chip + lime "Đổi mật khẩu" button.
- NotificationsScreen: rewrote `typeStyle` — each type now bold color text on 20% opacity tinted bg (info #144fcc, success #16a34a, warning #f59e0b, danger #dc2626). Unread dot → `bg-[#144fcc]` blue (was `bg-primary` = invisible lime on warm-white). Unread card border/bg → `border-[#144fcc]/40 bg-[#144fcc]/5`. "Đánh dấu đã đọc" button → `variant="outlined" className="border-[#14140f] text-[#14140f]"` (was `text-primary` = invisible).
- SupportScreen: contact icon circles → bold per-row colors (Phone blue+white, Mail coral+dark, MapPin dark+lime) via inline style. Success confirmation rebuilt as **dark card with lime accent** — `bg-[#14140f] text-white` with lime CheckCircle2 chip, title in lime, body in white/80. Form card → `bg-surface-container-low`.
- SettingsScreen: both toggle cards → `bg-surface-container-low`. Section header text → `text-[#14140f] font-bold`. Privacy Shield icon tinted `text-[#144fcc]` blue. All toggle row text wrapped with `min-w-0` + `truncate`.
- MyUniversityScreen: university hero keeps real logoUrl in white rounded container + uni.color gradient. Verification StatCards already bold via primitives accent map (success/primary/tertiary = #16a34a/#14140f/#ff8c5f). Route icon circles → per-route bold colors (DN-01 lime+dark, DN-03 blue+white) via inline style. Route code → `text-[#14140f]` (was invisible `text-primary`). Subsidy card rebuilt as **bold coral block** `bg-[#ff8c5f] text-[#14140f]` with dark+lime Gift icon chip.
- Mobile fixes: root wrapper for every screen = `min-w-0 overflow-x-hidden`. Added `min-w-0` + `truncate` to all flex/grid text children (avatar name/email/role fields, contact list items, toggle labels, route name/from-to, subsidy line items, notification titles). All icon circles get `shrink-0`.
- Lint: initial run flagged 1 unused eslint-disable directive on `<img>` (Next.js config in this project allows plain img). Removed directive. Final `bun run lint` → exit 0, 0 errors, 0 warnings. Dev log shows clean compilation.

Stage Summary:
- File: src/components/bus/common-screens.tsx (ONLY file modified — no other files touched).
- All 5 common screens redesigned perk-style with bold color blocks, dark accent cards (security, success, subsidy), blue unread dot, bold icon circles. Used literal hex throughout so perk palette renders across ALL roles (not just student scope where CSS tokens are scoped).
- Mobile overflow fixed: `min-w-0` + `truncate` + `overflow-x-hidden` everywhere needed.
- Lint clean (0/0), dev server compiles cleanly.
- Detailed work record: /agent-ctx/29-common-screens-perk-redesign.md

---
Task ID: 32
Agent: full-stack-developer (Admin+UniAdmin perk redesign)
Task: Redesign Admin (10) + University-Admin (9) modules perk-style + mobile fix

Work Log:
- Read worklog Task 28 design mandate + both module files (2524 + 3064 lines) + primitives.tsx + globals.css to confirm perk token overrides (primary-container=#14140f, secondary-container=#144fcc, tertiary-container=#ff8c5f).
- Admin module (10 screens): switched recharts to perk palette — revenue AreaChart stroke var(--color-primary)→#144fcc (lime invisible on white), gradient→blue, roleDist PieChart colors var(--color-chart-4/5) oklch→literal hex (#beff50/#ff8c5f/#144fcc/#c8a0ff/#f59e0b), all tooltip bgs→bold #14140f with lime #beff50 text. Added min-w-0+truncate to roleDist legend, user-detail name, fare-history items. Tables already overflow-x-auto scrollbar-soft.
- University-Admin module (9 screens): replaced ALL old-palette chart fills — passesByRoute (#10b981/#f59e0b/#14b8a6→#beff50/#144fcc/#ff8c5f) in Dashboard+Stats, facultyDist (5 colors→perk palette incl #c8a0ff purple), topRoutes (3 fills→perk), 2 LineCharts stroke var(--m3-primary)→#144fcc. Killed 4 pale-tint containers: bg-primary-container/40 (Domains intro)→bg-surface-container-low, bg-warning-container/60 (Import errors)→bold bg-warning-container text-[#14140f], bg-secondary-container/50 (Roster dialog note)→bg-surface-container-low border, bg-secondary-container/40 (Recon note)→bg-surface-container-low. Fixed text-primary on light bg: CalendarDays icon→text-[#144fcc]. Added min-w-0+truncate to: quick-action labels, campus name, domains cell, roster cell, top-routes cell, recon breakdown cell.
- Lint caught 1 typo (template-literal quote mismatch in BarChart tooltip formatter) — fixed [`${v} chuyến", ...]→[`${v} chuyến`, ...].
- Verified: no remaining bg-*-container/NN pale tints, no var(--color-chart-4/5) oklch, no #10b981/#14b8a6/#ec4899/#9333ea old-palette fills, no var(--m3-primary) lime strokes on light charts.

Stage Summary:
- Files: src/components/bus/roles/admin-module.tsx, src/components/bus/roles/university-admin-module.tsx
- Lint: PASS (exit 0, after 1 typo fix)
- Both modules fully perk-style: bold StatCards, bold container tints (auto via updated CSS tokens), perk-palette recharts (#beff50/#144fcc/#ff8c5f/#c8a0ff), dark tooltips with lime text, zero pale-tint backgrounds, mobile-safe with min-w-0+truncate on all flex/grid text children.

---
Task ID: 31
Agent: full-stack-developer (Coordinator perk redesign)
Task: Redesign Coordinator (10 screens) perk-style + mobile fix

Work Log:
- Read worklog.md (Task 28 design mandate) + full coordinator-module.tsx (3285 lines, 10 screens).
- Confirmed CSS tokens already bold globally: primary-container=#14140f, secondary-container=#144fcc, tertiary-container=#ff8c5f, error/success/warning containers bold. StatCard primitive already uses bold color blocks. Icon circles using bg-*-container already render bold via tokens — no change needed there.
- Selection states — killed all pale opacity tints (bg-primary-container/30,/40,/15,/50 and bg-secondary-container/50) which created muddy grey washes on the now-dark primary-container:
  * Live map side list selected: bg-secondary-container/50 → solid bg-secondary-container text-on-secondary-container (bold blue row).
  * Schedule today header: bg-primary-container/30 → bg-[#14140f] text-[#beff50] (bold dark column header, lime text; date circle bg-primary pops on dark).
  * Schedule today body cells: bg-primary-container/15 → bg-surface-container-lowest (neutral subtle highlight).
  * Schedule "Phân công" buttons hover: hover:bg-primary-container/30 → hover:bg-[#beff50] hover:text-[#14140f] hover:border-[#beff50] (bold lime hover).
  * Assign-driver card selected: bg-primary-container/40 → bg-[#beff50] border-[#beff50] text-[#14140f]. Details div conditional text-[#14140f]/70 (selected) vs text-on-surface-variant (default).
  * Assign-bus card selected: same bold lime treatment; model <p> + details div both conditional.
  * By-university summary card selected: bg-primary-container/30 → bg-[#beff50] border-[#beff50] text-[#14140f]; added min-w-0 to root.
- By-university hero card — replaced pale color-mix gradient with bold dark hero:
  * bg-[#14140f] + borderTop 4px solid uni.color (accent stripe).
  * Title text-on-surface → text-[#beff50] (lime on dark). Address → text-white/70.
  * Hash code chip bg-surface-container-highest → bg-[#beff50] text-[#14140f] (bold lime chip).
  * 3 stat boxes (were pale bg-surface-container/80): now bold multi-color perk blocks — Sinh viên=#beff50 lime, Tuyến=#ff8c5f coral, Cơ sở=#144fcc blue. Text dark/white for contrast. Added tabular-nums + min-w-0 + shrink-0.
- text-primary → text-[#144fcc] (2 instances: Wallet subsidy icon + subsidy amount span; primary #beff50 lime unreadable on light card bg).
- LIVE badges (dashboard + live map header): added text-white; pulse dots bg-success → bg-white (more visible on bold green #16a34a).
- Mobile fix — min-w-0 + truncate on flex/grid text children:
  * Uni trips table cell: flex → flex min-w-0; route name span got min-w-0 truncate.
  * Uni drivers table cell: avatar div got shrink-0; content div got min-w-0; name + phone <p> got truncate.
  * By-university route card: ExpressiveCard got min-w-0; route name + from→to got truncate.
- Tables already wrapped in overflow-x-auto scrollbar-soft (verified all 5 tables: routes, stops, schedule matrix, uni trips, uni drivers, feedback).
- Did NOT modify BusMap/RealMap (parallax aurora kept as functional map background, not a pale card). Did NOT touch other files.
- Ran `bun run lint` → exit 0, no errors. Dev server compiling clean.

Stage Summary:
- File: src/components/bus/roles/coordinator-module.tsx
- Lint: exit 0 (clean)
- All 10 coordinator screens now perk-style bold: dashboard (bold StatCards + live list + bold red incidents panel), live map (bold blue side-list selection), schedule (bold dark today column + bold shift chips), assign-driver/bus (bold lime selected cards), routes/stops (bold color dots + bold icon chips), by-university (bold dark hero with multi-color stat blocks + bold lime summary cards), feedback (bold StatCards), notify (bold priority preview card).
- Mobile overflow fixed: min-w-0 + truncate on all table cell text children + grid route cards.
- No pale tonal containers remain (all /30,/40,/15,/50 opacity tints eliminated).

---
Task ID: 30
Agent: full-stack-developer (Driver+Assistant perk redesign)
Task: Redesign Driver (6) + Assistant (7) modules perk-style + mobile fix

Work Log:
- READ worklog Task 28 mandate + both target files + primitives.tsx + m3/primitives.tsx + globals.css to confirm CSS token overrides (primary-container=#14140f, secondary-container=#144fcc, tertiary-container=#ff8c5f, success/error/warning containers all bold).
- Driver module: HorizontalTimeline + VerticalTimeline circles — done=bg-[#144fcc] text-white, active=bg-[#beff50] text-[#14140f], ping=bg-[#beff50]/40, connectors=bg-[#144fcc], labels=text-[#144fcc]; added min-w-0+truncate on stop cells. RouteMapSVG live dot → bg-[#144fcc]. DriverDashboard greeting+truncate; active-trip HERO rewritten pale lime→coral aurora → bold dark bg-[#14140f] with lime stripe/badge/tiles/CTA. DriverSchedule today date → text-[#144fcc]; trip departure chip explicit bg-[#14140f] text-[#beff50]; trip title min-w-0+truncate. DriverActiveTrip HERO rewritten → bold dark with lime/coral status pill, lime timer, lime progress bar, lime "Bắt đầu" + red "Kết thúc" + outlined lime "+1 khách"; passenger progress bar → bg-[#144fcc]; side panel icons → text-[#144fcc]; assistant card avatar shrink-0 + phone truncate. DriverRoute hero rewritten pale ROUTE.color gradient → bold dark with lime code badge + green/coral active badge + lime arrow + white stat tiles; stop-list + bus-info icons → text-[#144fcc]; grid min-w-0. DriverContact chat "me" bubble → bg-[#144fcc] text-white; timestamp text-white/70; message break-words.
- Assistant module: AssistantDashboard greeting+truncate; trip-info HERO rewritten pale lime→coral aurora → bold dark bg-[#14140f] with lime stripe/badge/tiles/icon; driver-contact card avatar shrink-0 + phone truncate; "Gọi" button text-primary → text-[#144fcc]. AssistantScan viewfinder kept dark with lime scan-line/brackets/center QR (bold on dark); status icon circles already bold containers. AssistantMonthly result HERO rewritten pale coral→lime aurora → bold dark with lime stripe + GREEN "VÉ THÁNG HỢP LỆ" badge + lime days counter + white stat tiles + lime CTA. AssistantLost form header icon → text-[#144fcc]. AssistantContact chat "me" bubble → bg-[#144fcc] text-white; sender name labels explicit text-[#ff8c5f] (driver) / text-[#144fcc] (coordinator); message break-words. AssistantHistory + AssistantIncident already used bold container tokens — preserved.
- Ran `bun run lint` — clean (0 errors, 0 warnings). Dev server compiles cleanly.

Stage Summary:
- Files: src/components/bus/roles/driver-module.tsx, src/components/bus/roles/assistant-module.tsx
- Lint: PASS (0 errors, 0 warnings)
- Hero cards (5): DriverDashboard active-trip, DriverActiveTrip hero, DriverRoute hero, AssistantDashboard trip-info, AssistantMonthly result — ALL converted from pale lime/coral aurora gradients to bold dark #14140f cards with lime #beff50 accent stripes + lime badges/CTAs + white headlines.
- Timeline circles: done = bold blue #144fcc, active = bold lime #beff50 (was pale lime throughout).
- Icon accents on light cards: all text-primary (lime, unreadable on light) → text-[#144fcc] (blue). Only remaining bg-primary text-on-primary is the week-selector selected day (bold lime brand accent — intentional).
- Chat bubbles: "me" bubbles → bold blue #144fcc + white text (was pale lime + dark).
- Mobile fix: min-w-0 + truncate added to all flex/grid text children in greetings, hero headlines, timeline cells, contact cards, trip lists, route stat tiles.
- Already-bold tokens preserved: bg-primary-container (dark), bg-secondary-container (blue), bg-tertiary-container (coral), bg-success/error/warning-container — all already render bold per Task 28 CSS overrides.

---
Task ID: 33
Agent: main (orchestrator)
Task: Full perk-style redesign verification — homepage, register, nav animation, mobile.

Work Log:
- Redefined CSS tokens (globals.css): primary-container=#14140f (was #e8ffa3 pale), secondary-container=#144fcc, tertiary-container=#ff8c5f, success-container=#16a34a, error-container=#dc2626, warning-container=#f59e0b. This kills ALL pale containers globally — any `bg-*-container` now renders BOLD.
- Rebuilt primitives.tsx: PageHeader icon chip = bg-[#14140f] text-[#beff50], StatCard = bold color blocks (dark/lime/coral/blue/purple) NOT pale tonal, Section min-w-0, EmptyState dark icon.
- Rebuilt auth-screens.tsx: hero "Đi xe bus đến trường" (removed vague "mềm mại như lời chào"), bold lime/dark/coral background blobs, dark preview card, SEPARATE register form (Google signup + email/password + SĐT + vai trò + terms), top nav has both "Đăng nhập" + "Đăng ký" buttons, perk-style stats counters (bold color blocks), AnimatePresence transitions between login/register/forgot.
- Rebuilt app-shell nav: motion.button with whileHover x:2 + whileTap scale:0.98, layoutId pill = full bg-[#14140f] rounded-full (smooth spring slide between items), active item text-[#beff50] lime, badge bg-[#beff50] on active / bg-[#dc2626] on inactive.
- Dispatched 4 parallel subagents (Task 29-32) to redesign all role modules + common-screens perk-style + mobile fix.
- All subagents completed: replaced text-primary→text-[#144fcc], tonal-container icon circles→bold, pale aurora heroes→bold dark/lime/coral, added min-w-0+truncate everywhere.
- Verified via agent-browser + pixel sampling:
  * Homepage: bold lime #beff50 ✓, concise text ✓, register button separate ✓
  * Register page: full form (Google + email + SĐT + vai trò + terms) ✓
  * Mobile student dashboard: scrollWidth=390=innerWidth, NO overflow ✓
  * Desktop student: lime 14426px, dark 6711px, blue 4543px, coral 4441px, purple 4457px — all bold colors present ✓
  * Pale lime remnants: 6px (JPEG compression, not real color) ✓
- Final `bun run lint` → exit 0.

Stage Summary:
- FULL perk-style redesign complete across ALL screens (auth, common, 5 role modules).
- ALL pale tonal containers killed (CSS tokens redefined to bold).
- Mobile overflow fixed (overflow-x-hidden + min-w-0 + truncate everywhere).
- Nav animation smooth (spring layoutId pill + hover lift).
- Homepage text concise, separate register page added.
- Lint clean, browser-verified, pixel-verified.

---
Task ID: 34
Agent: full-stack-developer (Student sub-screens perk redesign)

Task: Redesign 3 student sub-screens (StopsScreen, FindRoutesScreen, HistoryScreen) to perk.com style — bold color blocks, no pale tints, no shadows, min-w-0+truncate everywhere.

File: src/components/bus/roles/student-module.tsx (ONLY this file modified).

Work Log:
- READ worklog Task 28/33 mandate + current 3 screen implementations + primitives.tsx (StatCard bold accents, PageHeader dark icon chip) + m3/primitives.tsx (ExpressiveCard, StatusPill tones) + globals.css (CSS tokens: primary-container=#14140f, secondary-container=#144fcc, tertiary-container=#ff8c5f, elev-* all = box-shadow:none).
- Verified Routes colors in mock-data.ts (r1=#beff50 lime, r2=#f59e0b amber, r3=#14b8a6 teal, r4=#ec4899 pink) — used bold inline for route code badges.

1) StopsScreen (stu-stops — Trạm dừng) — full rewrite:
   - Search bar: bg-white + border-4 border-[#14140f] (was bg-surface-container-low + border-2 border-outline-variant) → focus:border-[#144fcc] blue; Search icon text-[#144fcc]; placeholder font-semibold #14140f.
   - Map preview hero: was bg-aurora-m3 (pale tonal gradient) → bg-[#14140f] BOLD DARK with #beff50/#ff8c5f/#144fcc color blobs; pulsing dots bg-primary→bg-[#beff50] lime with ring-[#14140f]; bottom strip added "Bản đồ" lime chip; white headline + white/70 sub.
   - Stop cards: ExpressiveCard → bg-white border-2 border-[#14140f]/10 hover:border-[#144fcc]; MapPin icon chip bg-primary-container (already #14140f bold) → explicit bg-[#14140f] text-[#beff50]; stop name text-on-surface→text-[#14140f] bold; stop code text-on-surface-variant→text-[#144fcc] bold blue; hasShelter badge bg-surface-container-highest→bg-[#16a34a] text-white bold green; route code chips h-5 px-2→h-6 px-2.5 text-[10px] font-bold (bold); UniRouteChip replaced inline with bg-[#ff8c5f] text-[#14140f] coral chip + School icon + university shortName.
   - Detail dialog: was plain DialogContent → now bg-white border-2 border-[#14140f]/10 with BOLD DARK HEADER BAND (bg-[#14140f] px-6 pt-6 pb-5) containing lime MapPin chip + "Mã trạm" lime chip + "Mái che" green chip + white title + white/70 description; body p-6 with "Lượt xe tiếp theo" label text-[#144fcc] bold uppercase; route rows bg-[#14140f]/5 hover:border-[#144fcc]; ETA time text-primary→text-[#144fcc] bold tabular-nums; "Đóng" button text-[#144fcc].
   - Mobile fix: min-w-0+truncate on stop name, code, address (line-clamp-2), header strip title/subtitle, dialog title/description (break-words), route rows.

2) FindRoutesScreen (stu-find — Tìm tuyến xe) — full rewrite of results + search hero:
   - Search form: was ExpressiveCard variant=filled (pale) → BOLD DARK HERO div bg-[#14140f] rounded-3xl with lime/coral blobs; labels text-on-surface-variant→text-[#beff50] bold uppercase; SelectTriggers/Input bg-white border-2 border-[#beff50]/30 text-[#14140f] font-semibold; "Tìm tuyến" ExpressiveButton bg-[#beff50] text-[#14140f].
   - Results: was tonal ExpressiveCards with isUni ring-tertiary/40 → BOLD COLOR BLOCKS with alternating palettes (idx%3):
     * idx%3===0: bg=#14140f dark + fg=white + accent=#beff50 lime + chip lime-on-dark
     * idx%3===1: bg=#144fcc blue + fg=white + accent=#beff50 lime + chip lime-on-blue
     * idx%3===2: bg=#ff8c5f coral + fg=#14140f dark + accent=#14140f dark + chip dark-with-lime
   - Route badge: was RouteCodeBadge (uses route.color) → BOLD inline-flex h-9 chip with Bus icon + route.code using pal.chipBg/pal.chipFg (alternating lime/dark).
   - Route name: text-on-surface→font-bold style={{color:pal.fg}}; from→to sub opacity-80 + truncate on both ends + ArrowLeftRight shrink-0.
   - UniRouteChip: bg-tertiary-container (#ff8c5f coral already bold) → inline coral chip OR white-on-coral variant.
   - Stat tiles (4 metrics): bg-surface-container-low (pale) → rgba(255,255,255,0.12) on dark/blue OR rgba(20,20,15,0.10) on coral; m.icon style={{color:pal.accent}}; value font-bold.
   - Timeline strip: bg-surface-container-low (pale) → DARK strip (idx%3===2 ? #14140f : idx%3===1 ? #0d3a99 darker blue : #1f1f17 off-black); label style={{color:pal.accent}}; dots size-2.5→size-3 rounded-full style={{backgroundColor:pal.accent}}; connector h-px→h-0.5 width-6; stop labels text-white/80 max-w-16 truncate.
   - Tạm dừng StatusPill (warning tone=bg-warning #f59e0b) → custom amber chip bg-[#f59e0b] text-[#14140f] with dark dot.
   - Action buttons: ExpressiveButton variant=text/tonal → custom outlined button (border-2 borderColor:pal.accent color:pal.accent) + filled button (bg:pal.accent color:pal.bg) for "Đăng ký tuyến".
   - Mobile fix: min-w-0 on all flex children + form grid cells; truncate on route name, from, to, "Hoạt động" time range; shrink-0 on icons, badges, buttons.

3) HistoryScreen (stu-history — Lịch sử chuyến) — partial rewrite (table only):
   - StatCards already bold (via primitives accentMap: primary=dark+lime, tertiary=coral+dark, secondary=blue+lime) — PRESERVED.
   - Filter select: bg-surface-container-low border-outline-variant → bg-white border-2 border-[#14140f] text-[#14140f] font-semibold.
   - "Xuất file" button: → border-[#144fcc] text-[#144fcc] hover:bg-[#144fcc]/10.
   - Table container: ExpressiveCard variant=filled p-0 → div rounded-2xl border-2 border-[#14140f]/10 bg-white.
   - Table header: bg-surface-container-high (pale) → bg-[#14140f] BOLD DARK; TableRow border-[#14140f] hover:bg-transparent; TableHead text-xs font-bold text-[#beff50] uppercase tracking-wide.
   - Table rows: alternating tints idx%2===0 ? bg-white : bg-[#144fcc]/5 (light blue tint); hover:bg-[#beff50]/20 lime tint; border-[#14140f]/10.
   - Date cell: text-on-surface-variant → text-[#14140f] font-semibold tabular-nums.
   - Time cell: text-on-surface-variant → text-[#14140f]/70 tabular-nums.
   - Fare cell: text-on-surface font-semibold → text-[#144fcc] font-bold tabular-nums (blue accent).
   - Status: StatusPill tone="success" (bg-success-container #16a34a bold) → custom BOLD green chip bg-[#16a34a] text-white text-[11px] font-bold with CheckCircle2 icon.
   - Empty state: text-on-surface-variant → text-[#14140f]/60.
   - Mobile fix: min-w-0 on TableCell route, tabular-nums on numeric cells.

Lint: ran `cd /home/z/my-project && bun run lint` → exit 0, no errors, no warnings.
Dev server log: ✓ Compiled cleanly, all GET / 200 OK (QrCode error visible in log is from auth-screens.tsx — NOT this file — out of scope, did NOT touch).

Stage Summary:
- File: src/components/bus/roles/student-module.tsx
- 3 student sub-screens redesigned perk-style: StopsScreen (dark map hero + white cards with bold route badges + dark-header dialog), FindRoutesScreen (dark search hero + alternating dark/blue/coral result blocks with bold route chip + dark timeline strip), HistoryScreen (dark header row + alternating row tints + bold green status chip + blue fare accent).
- All pale aurora/tonal surfaces eliminated from these 3 screens; replaced with BOLD color blocks (#14140f, #144fcc, #ff8c5f, #beff50, #16a34a, #f59e0b).
- text-primary (lime) on light bg → text-[#144fcc] (blue) wherever needed (search icon, dialog ETA time, dialog labels, "Đóng" button, fare cell, "Xuất file" button).
- min-w-0 + truncate applied to ALL flex/grid text children across 3 screens (stop names, codes, addresses, route names, from→to, time ranges, dialog title/description).
- StatCards in HistoryScreen preserved (already bold via primitives accentMap).
- No shadows used (elev-* = box-shadow:none per globals.css); elevation via tonal surface containers (white bg with dark border) + bold color blocks.
- Did NOT modify common-screens.tsx (NotificationsScreen per task instructions skip). Did NOT touch other files.
